
import { useState, useCallback } from 'react';

interface HistoryState<T> {
  past: T[];
  present: T;
  future: T[];
}

// Generic hook for undo/redo history
export function useHistory<T>(initialState: T) {
  // We use a single state object to ensure atomic updates for history and index
  // This prevents race conditions where 'history' or 'index' might be stale in closures
  const [historyState, setHistoryState] = useState<{
    history: T[];
    index: number;
  }>({
    history: [initialState],
    index: 0
  });

  const { history, index } = historyState;
  
  // Guard to ensure we always have a valid state.
  const state = history[index] ?? history[history.length - 1] ?? initialState;

  // Push new state to history
  const setState = useCallback((newState: T | ((prev: T) => T)) => {
    setHistoryState(prevState => {
      const { history: prevHistory, index: prevIndex } = prevState;
      const currentItem = prevHistory[prevIndex] ?? prevHistory[prevHistory.length - 1];
      
      const resolvedState = typeof newState === 'function' ? (newState as Function)(currentItem) : newState;
      
      // Create new history path branching from current index
      const nextHistory = prevHistory.slice(0, prevIndex + 1);
      nextHistory.push(resolvedState);

      // Enforce limit (e.g., 50 steps)
      if (nextHistory.length > 50) {
        nextHistory.shift();
        return {
          history: nextHistory,
          index: nextHistory.length - 1
        };
      } else {
        return {
          history: nextHistory,
          index: nextHistory.length - 1
        };
      }
    });
  }, []);

  // Overwrite the CURRENT state in history without pushing a new entry
  // Useful for continuous updates like dragging/resizing to prevent history spam
  const overwrite = useCallback((newState: T | ((prev: T) => T)) => {
    setHistoryState(prevState => {
      const { history: prevHistory, index: prevIndex } = prevState;
      const currentItem = prevHistory[prevIndex];
      const resolvedState = typeof newState === 'function' ? (newState as Function)(currentItem) : newState;
      
      // Update the current item in history array
      const nextHistory = [...prevHistory];
      nextHistory[prevIndex] = resolvedState;
      
      return {
        history: nextHistory,
        index: prevIndex
      };
    });
  }, []);

  const resetHistory = useCallback((newState: T) => {
    setHistoryState({
      history: [newState],
      index: 0
    });
  }, []);

  const undo = useCallback(() => {
    setHistoryState(prev => ({
      ...prev,
      index: Math.max(0, prev.index - 1)
    }));
  }, []);

  const redo = useCallback(() => {
    setHistoryState(prev => ({
      ...prev,
      index: Math.min(prev.history.length - 1, prev.index + 1)
    }));
  }, []);

  const canUndo = index > 0;
  const canRedo = index < history.length - 1;

  return {
    state,
    setState,
    overwrite,
    undo,
    redo,
    canUndo,
    canRedo,
    resetHistory
  };
}
