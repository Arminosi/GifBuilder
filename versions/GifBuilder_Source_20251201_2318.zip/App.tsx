
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Upload, Play, Download, Trash2, Undo2, Redo2, 
  History, Save, ArrowDownAZ, ArrowUpAZ, Loader2, ImagePlus, Languages, X as XIcon, Maximize, Scaling,
  Eye, Monitor, Palette, AlertCircle, Check, PanelLeft, Layout, Minimize2, CheckSquare, Layers, Package, Copy, Plus, FilePlus, ClipboardCopy, ClipboardPaste, RotateCcw
} from 'lucide-react';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent, DragOverlay, DragStartEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, rectSortingStrategy } from '@dnd-kit/sortable';
import { FrameData, CanvasConfig, HistorySnapshot } from './types';
import { FrameItem, FrameCard } from './components/FrameItem';
import { CanvasEditor } from './components/CanvasEditor';
import { VirtualFrameList } from './components/VirtualFrameList';
import { useHistory } from './hooks/useHistory';
import { generateGIF } from './utils/gifHelper';
import { generateFrameZip } from './utils/zipHelper';
import { translations, Language } from './utils/translations';
import { 
  saveSnapshotToDB, 
  getSnapshotsFromDB, 
  deleteSnapshotFromDB, 
  clearSnapshotsFromDB 
} from './utils/storage';

// Initial states
const INITIAL_CANVAS_CONFIG: CanvasConfig = {
  width: 500,
  height: 500,
  quality: 10,
  repeat: 0,
  transparent: null,
  backgroundColor: '#ffffff'
};

interface AppState {
  frames: FrameData[];
  canvasConfig: CanvasConfig;
}

const App: React.FC = () => {
  // Use custom history hook for Undo/Redo
  const { state: appState, setState: setAppState, overwrite: overwriteAppState, undo, redo, canUndo, canRedo } = useHistory<AppState>({
    frames: [],
    canvasConfig: INITIAL_CANVAS_CONFIG
  });

  // Safe destructuring with fallback
  const { frames, canvasConfig } = appState || { frames: [], canvasConfig: INITIAL_CANVAS_CONFIG };

  const [isGenerating, setIsGenerating] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [progress, setProgress] = useState(0);
  const [generatedGif, setGeneratedGif] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [snapshots, setSnapshots] = useState<HistorySnapshot[]>([]);
  const [showSnapshots, setShowSnapshots] = useState(false);
  const [globalDuration, setGlobalDuration] = useState(100);
  const [language, setLanguage] = useState<Language>('zh');
  const [fitMode, setFitMode] = useState<'fill' | 'contain'>('fill');
  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  
  // Selection State
  const [selectedFrameIds, setSelectedFrameIds] = useState<Set<string>>(new Set());
  const [batchInputValues, setBatchInputValues] = useState<{
    x: string;
    y: string;
    width: string;
    height: string;
    duration: string;
  }>({ x: '', y: '', width: '', height: '', duration: '' });
  
  // Clipboard State
  const [clipboard, setClipboard] = useState<FrameData[]>([]);
  
  // View options
  const [frameSize, setFrameSize] = useState(150);
  const [compactMode, setCompactMode] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showCanvasEditor, setShowCanvasEditor] = useState(true);
  
  // Confirm states
  const [clearHistoryConfirm, setClearHistoryConfirm] = useState(false);
  const [clearFramesConfirm, setClearFramesConfirm] = useState(false);
  const [restoreConfirmId, setRestoreConfirmId] = useState<string | null>(null);

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, insertIndex: number } | null>(null);
  // Insert Modal State
  const [showInsertModal, setShowInsertModal] = useState(false);
  const [insertTargetIndex, setInsertTargetIndex] = useState<number | null>(null);

  const t = translations[language];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const insertFileInputRef = useRef<HTMLInputElement>(null);

  // DnD Sensors
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8, // Require movement before drag starts to allow clicks
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Load snapshots from DB on mount
  useEffect(() => {
    getSnapshotsFromDB().then(loadedSnapshots => {
      setSnapshots(loadedSnapshots);
    }).catch(err => {
      console.error("Failed to load snapshots history", err);
    });
  }, []);

  // Clear batch inputs when selection changes
  useEffect(() => {
    setBatchInputValues({ x: '', y: '', width: '', height: '', duration: '' });
  }, [selectedFrameIds]);

  // Close context menu on click elsewhere
  useEffect(() => {
    const handleClick = () => setContextMenu(null);
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // --- Actions ---

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'zh' : 'en');
  };

  // Helper to get last selected ID for range selection
  const lastSelectedIdRef = useRef<string | null>(null);

  const handleSelection = (id: string, e: React.MouseEvent) => {
    const { ctrlKey, metaKey, shiftKey } = e;
    const isMultiSelect = ctrlKey || metaKey;
    const isRangeSelect = shiftKey;

    setSelectedFrameIds(prev => {
      const next = new Set(prev);

      if (isRangeSelect && lastSelectedIdRef.current && frames.some(f => f.id === lastSelectedIdRef.current)) {
        const lastIndex = frames.findIndex(f => f.id === lastSelectedIdRef.current);
        const currentIndex = frames.findIndex(f => f.id === id);
        const start = Math.min(lastIndex, currentIndex);
        const end = Math.max(lastIndex, currentIndex);
        
        // Add range to selection
        for (let i = start; i <= end; i++) {
          next.add(frames[i].id);
        }
      } else if (isMultiSelect) {
        if (next.has(id)) {
          next.delete(id);
        } else {
          next.add(id);
        }
        lastSelectedIdRef.current = id;
      } else {
        // Single select
        next.clear();
        next.add(id);
        lastSelectedIdRef.current = id;
      }
      return next;
    });
  };

  // Copy to internal clipboard
  const handleCopy = useCallback(() => {
    if (selectedFrameIds.size === 0) return;
    const selectedFrames = frames
      .filter(f => selectedFrameIds.has(f.id))
      .sort((a, b) => frames.indexOf(a) - frames.indexOf(b));
    
    if (selectedFrames.length > 0) {
      setClipboard(selectedFrames);
    }
  }, [frames, selectedFrameIds]);

  // Paste from internal clipboard
  const handlePaste = useCallback(() => {
    if (clipboard.length === 0) return;

    // Create copies with new IDs
    const newFrames = clipboard.map(f => ({
      ...f,
      id: Math.random().toString(36).substr(2, 9)
    }));

    setAppState(prev => {
      // Determine insertion index
      // If items selected, insert after the last selected item
      // Else insert at end
      let insertIndex = prev.frames.length;
      if (selectedFrameIds.size > 0) {
        const selectedIndices = prev.frames
          .map((f, i) => selectedFrameIds.has(f.id) ? i : -1)
          .filter(i => i !== -1);
        
        if (selectedIndices.length > 0) {
          insertIndex = Math.max(...selectedIndices) + 1;
        }
      }

      const nextFrames = [...prev.frames];
      nextFrames.splice(insertIndex, 0, ...newFrames);
      return { ...prev, frames: nextFrames };
    });

    // Select the new frames
    const newIds = new Set(newFrames.map(f => f.id));
    setSelectedFrameIds(newIds);
    lastSelectedIdRef.current = newFrames[newFrames.length - 1].id;
  }, [clipboard, selectedFrameIds, setAppState]);

  const handleDuplicate = useCallback(() => {
    const selectedIdsArray = Array.from(selectedFrameIds);
    if (selectedIdsArray.length === 0) return;

    // Filter and sort selected frames based on current order
    const selectedFramesInOrder = frames
      .filter(f => selectedFrameIds.has(f.id))
      .sort((a, b) => frames.indexOf(a) - frames.indexOf(b));
    
    if (selectedFramesInOrder.length === 0) return;

    // Create copies with new IDs
    const newFrames: FrameData[] = selectedFramesInOrder.map(f => ({
      ...f,
      id: Math.random().toString(36).substr(2, 9)
    }));

    const newIds = new Set(newFrames.map(f => f.id));

    setAppState(prev => {
      // Find the index of the last selected item to insert after
      const lastSelectedIndex = prev.frames.reduce((lastIndex, frame, index) => {
        return selectedFrameIds.has(frame.id) ? index : lastIndex;
      }, -1);
      
      const nextFrames = [...prev.frames];
      // If no selection found (weird case), append to end. Otherwise insert after selection.
      const insertIndex = lastSelectedIndex === -1 ? nextFrames.length : lastSelectedIndex + 1;
      
      nextFrames.splice(insertIndex, 0, ...newFrames);
      
      return { ...prev, frames: nextFrames };
    });

    // Select the newly created frames
    setSelectedFrameIds(newIds);
    lastSelectedIdRef.current = newFrames[newFrames.length - 1].id;
  }, [selectedFrameIds, frames, setAppState]);

  // Context Menu Handlers
  const handleFrameContextMenu = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // If we right-click on an item that isn't selected, select it exclusively
    // This matches standard OS behavior
    if (!selectedFrameIds.has(id)) {
      setSelectedFrameIds(new Set([id]));
      lastSelectedIdRef.current = id;
    }
    
    const index = frames.findIndex(f => f.id === id);
    // Default to inserting AFTER the clicked item
    setContextMenu({ x: e.clientX, y: e.clientY, insertIndex: index + 1 });
  };

  const handleBackgroundContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Find closest frame to determine index for "Insert Here" functionality
    const framesElements = Array.from(document.querySelectorAll('[data-frame-id]'));
    let closestIndex = frames.length; // Default to end
    let minDistance = Infinity;

    if (framesElements.length > 0) {
        framesElements.forEach((el) => {
            const rect = el.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const dist = Math.hypot(e.clientX - centerX, e.clientY - centerY);
            
            // Limit detection range to avoid weird jumps if clicking far away
            if (dist < minDistance && dist < 500) {
                minDistance = dist;
                const id = el.getAttribute('data-frame-id');
                const index = frames.findIndex(f => f.id === id);
                
                if (index !== -1) {
                    // Simple heuristic: if mouse is to the right of center (LTR layout), insert after
                    // This works well for grid layouts
                    closestIndex = (e.clientX > centerX) ? index + 1 : index;
                }
            }
        });
    }

    setContextMenu({ x: e.clientX, y: e.clientY, insertIndex: closestIndex });
  };

  const handleBackgroundClick = (e: React.MouseEvent) => {
    // Only deselect if clicking directly on the background container, not its children
    if (e.target === e.currentTarget) {
      setSelectedFrameIds(new Set());
    }
  };

  const handleContextCopy = () => {
    handleCopy();
    setContextMenu(null);
  };

  const handleContextPaste = () => {
    if (!contextMenu || clipboard.length === 0) return;
    const { insertIndex } = contextMenu;

    const newFrames = clipboard.map(f => ({
      ...f,
      id: Math.random().toString(36).substr(2, 9)
    }));

    setAppState(prev => {
      const nextFrames = [...prev.frames];
      nextFrames.splice(insertIndex, 0, ...newFrames);
      return { ...prev, frames: nextFrames };
    });

    const newIds = new Set(newFrames.map(f => f.id));
    setSelectedFrameIds(newIds);
    setContextMenu(null);
  };

  const handleContextDuplicate = () => {
    if (!contextMenu) return;
    const { insertIndex } = contextMenu;
    
    const selectedIdsArray = Array.from(selectedFrameIds);
    if (selectedIdsArray.length === 0) return;

    const selectedFramesInOrder = frames
      .filter(f => selectedFrameIds.has(f.id))
      .sort((a, b) => frames.indexOf(a) - frames.indexOf(b));

    const newFrames: FrameData[] = selectedFramesInOrder.map(f => ({
      ...f,
      id: Math.random().toString(36).substr(2, 9)
    }));

    setAppState(prev => {
      const nextFrames = [...prev.frames];
      nextFrames.splice(insertIndex, 0, ...newFrames);
      return { ...prev, frames: nextFrames };
    });

    // Select new frames
    const newIds = new Set(newFrames.map(f => f.id));
    setSelectedFrameIds(newIds);
    setContextMenu(null);
  };

  const handleContextInsert = () => {
    if (!contextMenu) return;
    const { insertIndex } = contextMenu;
    
    setInsertTargetIndex(insertIndex);
    setShowInsertModal(true);
    setContextMenu(null);
  };

  const handleContextDelete = () => {
    if (!contextMenu) return;
    
    if (selectedFrameIds.size === 0) {
        setContextMenu(null);
        return;
    }

    setAppState(prev => ({
      ...prev,
      frames: prev.frames.filter(f => !selectedFrameIds.has(f.id))
    }));

    setSelectedFrameIds(new Set());
    setContextMenu(null);
  };

  const handleResetFrameProperties = () => {
    if (selectedFrameIds.size === 0) {
        setContextMenu(null); // Just close context menu if open
        return;
    }

    setAppState(prev => ({
      ...prev,
      frames: prev.frames.map(f => {
        if (selectedFrameIds.has(f.id)) {
          return {
            ...f,
            width: f.originalWidth,
            height: f.originalHeight,
            x: 0,
            y: 0
          };
        }
        return f;
      })
    }));
    
    setContextMenu(null);
  };

  const handleInsertFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    if (insertTargetIndex === null) return;

    const newFrames: FrameData[] = [];
    let firstImageWidth = 0;
    let firstImageHeight = 0;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) continue;

      const url = URL.createObjectURL(file);
      
      const img = new Image();
      img.src = url;
      await new Promise((resolve) => { img.onload = resolve; });

      if (i === 0) {
        firstImageWidth = img.naturalWidth;
        firstImageHeight = img.naturalHeight;
      }
      
      newFrames.push({
        id: Math.random().toString(36).substr(2, 9),
        file,
        previewUrl: url,
        duration: globalDuration,
        x: 0,
        y: 0,
        width: img.naturalWidth,
        height: img.naturalHeight,
        originalWidth: img.naturalWidth,
        originalHeight: img.naturalHeight,
      });
    }

    if (newFrames.length > 0) {
      setAppState(prev => {
        const nextFrames = [...prev.frames];
        nextFrames.splice(insertTargetIndex, 0, ...newFrames);
        
        // If it was empty, update canvas size
        const shouldSetSize = prev.frames.length === 0;
        
        return {
          ...prev,
          frames: nextFrames,
          canvasConfig: shouldSetSize ? {
            ...prev.canvasConfig,
            width: firstImageWidth,
            height: firstImageHeight
          } : prev.canvasConfig
        };
      });

      // Select new frames
      const newIds = new Set(newFrames.map(f => f.id));
      setSelectedFrameIds(newIds);
    }

    setShowInsertModal(false);
    setInsertTargetIndex(null);
  };

  // Keyboard Shortcuts Handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Input protection: don't trigger if user is typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.ctrlKey || e.metaKey) {
        switch(e.key.toLowerCase()) {
          case 'z':
            e.preventDefault();
            if (e.shiftKey) {
              if (canRedo) redo();
            } else {
              if (canUndo) undo();
            }
            break;
          case 'y':
            e.preventDefault();
            if (canRedo) redo();
            break;
          case 'd':
            e.preventDefault();
            handleDuplicate();
            break;
          case 'c':
            e.preventDefault();
            handleCopy();
            break;
          case 'v':
            e.preventDefault();
            handlePaste();
            break;
          case 'a':
            e.preventDefault();
            const allIds = new Set(frames.map(f => f.id));
            setSelectedFrameIds(allIds);
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [canUndo, canRedo, undo, redo, handleDuplicate, handleCopy, handlePaste, frames]);


  const handleFileUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const newFrames: FrameData[] = [];
    let firstImageWidth = 0;
    let firstImageHeight = 0;
    
    // Process files
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) continue;

      const url = URL.createObjectURL(file);
      
      const img = new Image();
      img.src = url;
      await new Promise((resolve) => { img.onload = resolve; });

      if (i === 0) {
        firstImageWidth = img.naturalWidth;
        firstImageHeight = img.naturalHeight;
      }
      
      newFrames.push({
        id: Math.random().toString(36).substr(2, 9),
        file,
        previewUrl: url,
        duration: globalDuration,
        x: 0,
        y: 0,
        width: img.naturalWidth,
        height: img.naturalHeight,
        originalWidth: img.naturalWidth,
        originalHeight: img.naturalHeight,
      });
    }

    if (newFrames.length > 0) {
      setAppState(prev => {
        const shouldSetSize = prev.frames.length === 0;
        return {
          ...prev,
          frames: [...prev.frames, ...newFrames],
          canvasConfig: shouldSetSize ? {
            ...prev.canvasConfig,
            width: firstImageWidth,
            height: firstImageHeight
          } : prev.canvasConfig
        };
      });

      if (selectedFrameIds.size === 0) {
        setSelectedFrameIds(new Set([newFrames[0].id]));
        lastSelectedIdRef.current = newFrames[0].id;
      }
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Disable global drag overlay if modal is open to prevent conflict
    if (showInsertModal) return;

    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleInsertDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleInsertFiles(e.dataTransfer.files);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files);
    }
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveDragId(event.active.id.toString());
    // Close context menu if open
    setContextMenu(null);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveDragId(null);

    if (over && active.id !== over.id) {
      setAppState(prev => {
        // Multi-drag support
        if (selectedFrameIds.has(active.id.toString()) && selectedFrameIds.size > 1) {
           
           const selectedIds = Array.from(selectedFrameIds);
           // Sort selected items by their current index to maintain relative order
           selectedIds.sort((a, b) => {
             return prev.frames.findIndex(f => f.id === a) - prev.frames.findIndex(f => f.id === b);
           });

           const framesWithoutSelected = prev.frames.filter(f => !selectedFrameIds.has(f.id));
           
           let insertIndex = framesWithoutSelected.findIndex(f => f.id === over.id);
           
           if (insertIndex === -1) {
              const oldIndex = prev.frames.findIndex(f => f.id === active.id);
              const newIndex = prev.frames.findIndex(f => f.id === over.id);
              return { ...prev, frames: arrayMove(prev.frames, oldIndex, newIndex) };
           }

           const activeIndex = prev.frames.findIndex(f => f.id === active.id);
           const overIndex = prev.frames.findIndex(f => f.id === over.id);
           
           if (activeIndex < overIndex) {
             insertIndex += 1;
           }

           const framesToInsert = selectedIds.map(id => prev.frames.find(f => f.id === id)!);
           const newFrames = [...framesWithoutSelected];
           newFrames.splice(insertIndex, 0, ...framesToInsert);
           
           return { ...prev, frames: newFrames };

        } else {
           // Single item move
           const oldIndex = prev.frames.findIndex(f => f.id === active.id);
           const newIndex = prev.frames.findIndex(f => f.id === over.id);
           return {
             ...prev,
             frames: arrayMove(prev.frames, oldIndex, newIndex)
           };
        }
      });
    }
  };

  const removeFrame = (id: string) => {
    setAppState(prev => ({
      ...prev,
      frames: prev.frames.filter(f => f.id !== id)
    }));
    if (selectedFrameIds.has(id)) {
      setSelectedFrameIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  };

  // Absolute update (from Sidebar or Inputs)
  const handleBatchUpdate = (updates: Partial<FrameData>) => {
    setAppState(prev => ({
      ...prev,
      frames: prev.frames.map(f => {
        if (selectedFrameIds.has(f.id)) {
          return { ...f, ...updates };
        }
        return f;
      })
    }));
  };

  const handleBatchInputChange = (field: keyof typeof batchInputValues, value: string) => {
    setBatchInputValues(prev => ({ ...prev, [field]: value }));
  };

  const applyBatchUpdates = () => {
    const updates: Partial<FrameData> = {};
    if (batchInputValues.x !== '') updates.x = parseInt(batchInputValues.x);
    if (batchInputValues.y !== '') updates.y = parseInt(batchInputValues.y);
    if (batchInputValues.width !== '') updates.width = parseInt(batchInputValues.width);
    if (batchInputValues.height !== '') updates.height = parseInt(batchInputValues.height);
    if (batchInputValues.duration !== '') updates.duration = parseInt(batchInputValues.duration);
    
    if (Object.keys(updates).length > 0) {
      handleBatchUpdate(updates);
    }
  };

  // Single update (FrameItem input)
  const updateFrame = (id: string, updates: Partial<FrameData>) => {
    setAppState(prev => ({
      ...prev,
      frames: prev.frames.map(f => f.id === id ? { ...f, ...updates } : f)
    }));
  };

  // Canvas Editor Updates
  // Receives absolute new attributes for the active frame.
  // Calculates the delta and applies it to all selected frames.
  const handleCanvasUpdate = (newAttrs: Partial<FrameData>, commit: boolean = true) => {
    const updateFn = (prev: AppState) => {
      // Find the active frame (the one being edited in the canvas)
      // We assume it's the last selected one as that's what we pass to CanvasEditor
      const activeId = Array.from(selectedFrameIds).pop();
      if (!activeId) return prev;

      const activeFrame = prev.frames.find(f => f.id === activeId);
      if (!activeFrame) return prev;

      // Calculate deltas based on the difference between the requested new attributes
      // and the current state of the active frame.
      const dx = newAttrs.x !== undefined ? newAttrs.x - activeFrame.x : 0;
      const dy = newAttrs.y !== undefined ? newAttrs.y - activeFrame.y : 0;
      const dw = newAttrs.width !== undefined ? newAttrs.width - activeFrame.width : 0;
      const dh = newAttrs.height !== undefined ? newAttrs.height - activeFrame.height : 0;

      return {
        ...prev,
        frames: prev.frames.map(f => {
          if (selectedFrameIds.has(f.id)) {
            return {
              ...f,
              x: Math.round(f.x + dx),
              y: Math.round(f.y + dy),
              width: Math.max(1, Math.round(f.width + dw)),
              height: Math.max(1, Math.round(f.height + dh)),
            };
          }
          return f;
        })
      };
    };

    if (commit) {
      setAppState(updateFn);
    } else {
      overwriteAppState(updateFn);
    }
  };

  const clearAll = useCallback(() => {
    if (clearFramesConfirm) {
      setAppState(prev => ({ ...prev, frames: [] }));
      setGeneratedGif(null);
      setSelectedFrameIds(new Set());
      setClearFramesConfirm(false);
    } else {
      setClearFramesConfirm(true);
      setTimeout(() => setClearFramesConfirm(false), 2000);
    }
  }, [clearFramesConfirm, setAppState]);

  const sortByFilename = (direction: 'asc' | 'desc') => {
    setAppState(prev => {
      const sorted = [...prev.frames].sort((a, b) => {
        const nameA = a.file.name;
        const nameB = b.file.name;
        return direction === 'asc' 
          ? nameA.localeCompare(nameB, undefined, { numeric: true, sensitivity: 'base' })
          : nameB.localeCompare(nameA, undefined, { numeric: true, sensitivity: 'base' });
      });
      return { ...prev, frames: sorted };
    });
  };

  const updateGlobalDuration = () => {
    setAppState(prev => ({
      ...prev,
      frames: prev.frames.map(f => ({ ...f, duration: globalDuration }))
    }));
  };

  const handleAutoFit = () => {
    const { width: canvasW, height: canvasH } = canvasConfig;
    
    setAppState(prev => ({
      ...prev,
      frames: prev.frames.map(frame => {
        let newWidth = frame.originalWidth;
        let newHeight = frame.originalHeight;
        let newX = 0;
        let newY = 0;

        if (fitMode === 'fill') {
          newWidth = canvasW;
          newHeight = canvasH;
        } else {
          // Contain logic
          const scale = Math.min(canvasW / frame.originalWidth, canvasH / frame.originalHeight);
          newWidth = Math.round(frame.originalWidth * scale);
          newHeight = Math.round(frame.originalHeight * scale);
          newX = Math.round((canvasW - newWidth) / 2);
          newY = Math.round((canvasH - newHeight) / 2);
        }

        return {
          ...frame,
          width: newWidth,
          height: newHeight,
          x: newX,
          y: newY
        };
      })
    }));
  };

  const saveSnapshot = useCallback(async (providedName?: string, thumbnail?: string, thumbnailBlob?: Blob) => {
    const name = providedName || prompt(translations[language].promptSave, `Version ${snapshots.length + 1}`);
    if (name) {
      const snapshot: HistorySnapshot = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        name,
        frames: [...frames],
        canvasConfig: { ...canvasConfig },
        thumbnail: thumbnail
      };
      
      setSnapshots(prev => [snapshot, ...prev]);
      if (!providedName) {
        setShowSnapshots(true);
      }

      try {
        await saveSnapshotToDB(snapshot, thumbnailBlob);
      } catch (e) {
        console.error("Failed to save snapshot to IndexedDB", e);
      }
    }
  }, [frames, canvasConfig, language, snapshots.length]);

  const restoreSnapshot = (snapshot: HistorySnapshot) => {
    if (restoreConfirmId === snapshot.id) {
      setAppState({
        frames: snapshot.frames,
        canvasConfig: snapshot.canvasConfig
      });
      setShowSnapshots(false);
      setRestoreConfirmId(null);
      setSelectedFrameIds(new Set());
    } else {
      setRestoreConfirmId(snapshot.id);
      setTimeout(() => setRestoreConfirmId(null), 2000);
    }
  };

  const deleteSnapshot = async (id: string) => {
     setSnapshots(prev => prev.filter(s => s.id !== id));
     try {
       await deleteSnapshotFromDB(id);
     } catch(e) {
       console.error("Failed to delete snapshot from DB", e);
     }
  };

  const clearHistoryRecords = async () => {
    if (clearHistoryConfirm) {
      setSnapshots([]);
      setClearHistoryConfirm(false);
      try {
        await clearSnapshotsFromDB();
      } catch(e) {
        console.error("Failed to clear DB", e);
      }
    } else {
      setClearHistoryConfirm(true);
      setTimeout(() => setClearHistoryConfirm(false), 2000);
    }
  };

  const handleGenerate = async () => {
    if (frames.length === 0) return;
    setIsGenerating(true);
    setProgress(0);
    setGeneratedGif(null);

    try {
      const blob = await generateGIF(frames, canvasConfig, (p) => setProgress(p * 100));
      const url = URL.createObjectURL(blob);
      setGeneratedGif(url);
      
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      saveSnapshot(`${t.autoSaved} - ${timeStr}`, url, blob);

    } catch (error) {
      console.error(error);
      alert(t.failed);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExportZip = async (sourceFrames = frames) => {
    if (sourceFrames.length === 0) return;
    setIsZipping(true);
    
    try {
      const blob = await generateFrameZip(sourceFrames);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `images_seq_${Date.now()}.zip`;
      a.click();
      URL.revokeObjectURL(url);

      // Save to history (only if we are packing the current frames)
      if (sourceFrames === frames) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        // Use first frame as thumbnail or no thumbnail
        saveSnapshot(`${t.zipSaved} - ${timeStr}`, undefined, undefined);
      }

    } catch (error) {
      console.error(error);
      alert("Failed to create ZIP");
    } finally {
      setIsZipping(false);
    }
  };

  const handleBgColorChange = (color: string) => {
    setAppState(prev => ({
      ...prev,
      canvasConfig: {
        ...prev.canvasConfig,
        backgroundColor: color,
        transparent: null
      }
    }));
  };

  const handleTransparentChange = (checked: boolean) => {
    setAppState(prev => ({
      ...prev,
      canvasConfig: {
        ...prev.canvasConfig,
        transparent: checked ? 'rgba(0,0,0,0)' : null
      }
    }));
  };

  // Find the primary selected frame for the editor (last selected usually)
  const lastSelectedId = Array.from(selectedFrameIds).pop();
  const selectedFrame = frames.find(f => f.id === lastSelectedId) || null;
  const selectedFrameIndex = frames.findIndex(f => f.id === lastSelectedId);
  const activeDragFrame = activeDragId ? frames.find(f => f.id === activeDragId) : null;

  // --- Render Helpers ---

  return (
    <div className="flex flex-col h-full bg-gray-950 text-gray-200" onDragEnter={handleDrag}>
      <style>{`
        .custom-scrollbar {
          scrollbar-width: thin;
          scrollbar-color: #4b5563 transparent;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #374151;
          border-radius: 20px;
          border: 2px solid transparent;
          background-clip: content-box;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background-color: #4b5563;
        }

        /* Number Input Spin Buttons Style Optimization for Dark Mode */
        input[type="number"] {
          color-scheme: dark;
        }
        
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
          opacity: 0.2;
          transition: opacity 0.2s;
          cursor: pointer;
          margin-left: 2px;
        }
        
        input[type="number"]:hover::-webkit-inner-spin-button,
        input[type="number"]:hover::-webkit-outer-spin-button,
        input[type="number"]:focus::-webkit-inner-spin-button,
        input[type="number"]:focus::-webkit-outer-spin-button {
          opacity: 1;
        }
      `}</style>
      
      {/* Header */}
      <header className="h-16 border-b border-gray-800 bg-gray-900/50 flex items-center justify-between px-6 shrink-0 z-20">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className={`p-2 rounded-lg hover:bg-gray-800 transition-colors mr-1 ${!isSidebarOpen ? 'bg-gray-800 text-blue-400' : 'text-gray-400'}`}
            title={t.toggleSidebar}
          >
            <PanelLeft size={20} />
          </button>

          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center font-bold text-white shadow-lg">
            GIF
          </div>
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
            GifBuilder
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
           {/* Language Switcher */}
           <button 
             onClick={toggleLanguage}
             className="p-2 hover:bg-gray-800 rounded-lg transition-colors text-gray-400 hover:text-white flex items-center gap-1.5 border border-transparent hover:border-gray-700"
             title={language === 'en' ? "Switch to Chinese" : "Switch to English"}
           >
             <Languages size={18} />
             <span className="text-sm font-medium">{language === 'en' ? 'EN' : '中文'}</span>
           </button>

           <div className="h-6 w-px bg-gray-800 mx-1"></div>

           {/* History Controls */}
           <div className="flex items-center bg-gray-800 rounded-lg p-1 border border-gray-700">
             <button 
              onClick={undo} disabled={!canUndo}
              className="p-2 hover:bg-gray-700 rounded disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title={t.undo}
             >
               <Undo2 size={18} />
             </button>
             <div className="w-px h-4 bg-gray-700 mx-1" />
             <button 
              onClick={redo} disabled={!canRedo}
              className="p-2 hover:bg-gray-700 rounded disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title={t.redo}
             >
               <Redo2 size={18} />
             </button>
           </div>
           
           <button 
             onClick={() => setShowSnapshots(!showSnapshots)}
             className={`p-2 rounded-lg border transition-colors flex items-center gap-2 ${showSnapshots ? 'bg-blue-600 border-blue-500 text-white' : 'bg-gray-800 border-gray-700 hover:bg-gray-700'}`}
           >
             <History size={18} />
             <span className="hidden sm:inline">{t.records}</span>
             {snapshots.length > 0 && (
                <span className="bg-blue-500 text-white text-[10px] px-1.5 rounded-full">{snapshots.length}</span>
             )}
           </button>

           {/* Export Buttons */}
           <div className="flex items-center gap-2">
             <button 
               onClick={() => handleExportZip(frames)}
               disabled={frames.length === 0 || isZipping}
               className="bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-gray-200 border border-gray-700 px-3 py-2 rounded-lg font-medium flex items-center gap-2 transition-all"
               title={t.exportZip}
             >
                {isZipping ? <Loader2 size={18} className="animate-spin" /> : <Package size={18} />}
                <span className="hidden xl:inline">{t.exportZip}</span>
             </button>

             <button 
               onClick={handleGenerate}
               disabled={frames.length === 0 || isGenerating}
               className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 shadow-lg shadow-blue-900/20 transition-all"
             >
               {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <Play size={18} fill="currentColor" />}
               {t.generate}
             </button>
           </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* Drag Overlay */}
        {dragActive && (
          <div 
            className="absolute inset-0 bg-blue-500/20 border-4 border-blue-500 border-dashed z-50 flex items-center justify-center backdrop-blur-sm"
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="bg-gray-900 p-8 rounded-xl shadow-2xl flex flex-col items-center pointer-events-none">
              <Upload size={48} className="text-blue-400 mb-4" />
              <h2 className="text-2xl font-bold text-white">{t.dropHere}</h2>
            </div>
          </div>
        )}

        {/* Left Sidebar: Controls & Upload */}
        <aside 
          className={`bg-gray-900 border-r border-gray-800 flex flex-col overflow-y-auto overflow-x-hidden shrink-0 custom-scrollbar transition-all duration-300 ease-in-out ${
            isSidebarOpen ? 'w-80 opacity-100' : 'w-0 opacity-0 border-r-0 overflow-hidden'
          }`}
        >
          <div className="w-80">
            <div className="p-5 space-y-6">
              
              {/* Upload Area */}
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-700 hover:border-blue-500 hover:bg-gray-800/50 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition-all group"
              >
                <input 
                  type="file" 
                  multiple 
                  accept="image/*" 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={(e) => handleFileUpload(e.target.files)}
                />
                <div className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <ImagePlus className="text-gray-400 group-hover:text-blue-400" size={24} />
                </div>
                <p className="text-sm font-medium text-gray-300 text-center">{t.clickDrag}</p>
                <p className="text-xs text-gray-500 mt-1">{t.supports}</p>
              </div>

              {/* Selection Properties (Conditional) */}
              {selectedFrameIds.size > 0 && (
                <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-300">
                   <h3 className="text-sm font-semibold text-blue-400 uppercase tracking-wider flex items-center gap-2">
                     <CheckSquare size={14} /> 
                     {t.selectionProperties}
                     <span className="text-[10px] bg-blue-900/50 text-blue-300 px-1.5 rounded">{selectedFrameIds.size}</span>
                   </h3>
                   <div className="bg-blue-950/20 border border-blue-900/50 p-3 rounded-lg space-y-3">
                      {/* Batch Inputs */}
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-xs text-blue-300/70 mb-1 block">{t.frame.x}</label>
                          <input type="number" 
                             value={batchInputValues.x}
                             placeholder={t.frame.x}
                             className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-xs"
                             onChange={(e) => handleBatchInputChange('x', e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-xs text-blue-300/70 mb-1 block">{t.frame.y}</label>
                          <input type="number" 
                             value={batchInputValues.y}
                             placeholder={t.frame.y}
                             className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-xs"
                             onChange={(e) => handleBatchInputChange('y', e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-xs text-blue-300/70 mb-1 block">{t.frame.w}</label>
                          <input type="number" 
                             value={batchInputValues.width}
                             placeholder={t.frame.w}
                             className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-xs"
                             onChange={(e) => handleBatchInputChange('width', e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-xs text-blue-300/70 mb-1 block">{t.frame.h}</label>
                          <input type="number" 
                             value={batchInputValues.height}
                             placeholder={t.frame.h}
                             className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-xs"
                             onChange={(e) => handleBatchInputChange('height', e.target.value)}
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="text-xs text-blue-300/70 mb-1 block">{t.frame.time}</label>
                          <input type="number" 
                             value={batchInputValues.duration}
                             placeholder={t.frame.time}
                             className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-xs"
                             onChange={(e) => handleBatchInputChange('duration', e.target.value)}
                          />
                        </div>
                      </div>
                      
                      <button 
                        onClick={applyBatchUpdates}
                        className="w-full flex items-center justify-center gap-2 p-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs transition-colors shadow-sm font-medium"
                      >
                        <Check size={12} /> {t.apply}
                      </button>

                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={handleDuplicate}
                          className="flex items-center justify-center gap-2 p-1.5 rounded bg-blue-900/30 hover:bg-blue-900/50 text-blue-300 border border-blue-900/50 text-xs transition-colors"
                          title={t.duplicateShortcut}
                        >
                          <Copy size={12} /> {t.duplicate}
                        </button>
                        <button 
                          onClick={handleResetFrameProperties}
                          className="flex items-center justify-center gap-2 p-1.5 rounded bg-blue-900/30 hover:bg-blue-900/50 text-blue-300 border border-blue-900/50 text-xs transition-colors"
                        >
                          <RotateCcw size={12} /> {t.resetProperties}
                        </button>
                      </div>
                   </div>
                </div>
              )}

              {/* View Options */}
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                  <Eye size={14} /> {t.viewOptions}
                </h3>
                <div className="bg-gray-800 p-3 rounded-lg border border-gray-700 space-y-3">
                  <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-xs text-gray-500">{t.frameSize}</label>
                        <span className="text-xs text-gray-400">{Math.round(frameSize/300 * 100)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="60" 
                        max="300" 
                        value={frameSize} 
                        onChange={(e) => setFrameSize(parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                  </div>
                  <div className="flex items-center justify-between">
                      <label className="text-sm text-gray-300 flex items-center gap-2">
                        <Monitor size={14} className="text-gray-500" />
                        {t.compactMode}
                      </label>
                      <button 
                        onClick={() => setCompactMode(!compactMode)}
                        className={`w-10 h-5 rounded-full relative transition-colors ${compactMode ? 'bg-blue-600' : 'bg-gray-600'}`}
                      >
                        <div className={`w-3 h-3 bg-white rounded-full absolute top-1 transition-all ${compactMode ? 'left-6' : 'left-1'}`} />
                      </button>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                      <label className="text-sm text-gray-300 flex items-center gap-2">
                        <Layout size={14} className="text-gray-500" />
                        {showCanvasEditor ? t.hideEditor : t.showEditor}
                      </label>
                      <button 
                        onClick={() => setShowCanvasEditor(!showCanvasEditor)}
                        className={`w-10 h-5 rounded-full relative transition-colors ${showCanvasEditor ? 'bg-blue-600' : 'bg-gray-600'}`}
                      >
                         <div className={`w-3 h-3 bg-white rounded-full absolute top-1 transition-all ${showCanvasEditor ? 'left-6' : 'left-1'}`} />
                      </button>
                  </div>
                </div>
              </div>

              {/* Canvas Settings */}
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">{t.canvasSettings}</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.width}</label>
                    <input 
                      type="number" 
                      value={canvasConfig.width}
                      onChange={(e) => setAppState(prev => ({ ...prev, canvasConfig: { ...prev.canvasConfig, width: parseInt(e.target.value) || 100 } }))}
                      className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.height}</label>
                    <input 
                      type="number" 
                      value={canvasConfig.height}
                      onChange={(e) => setAppState(prev => ({ ...prev, canvasConfig: { ...prev.canvasConfig, height: parseInt(e.target.value) || 100 } }))}
                      className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
                
                {/* Background Settings */}
                <div className="bg-gray-800 p-3 rounded-lg border border-gray-700 space-y-3">
                    <div className="flex items-center gap-2">
                      <input 
                        type="checkbox" 
                        id="transparent" 
                        checked={canvasConfig.transparent === 'rgba(0,0,0,0)'}
                        onChange={(e) => handleTransparentChange(e.target.checked)}
                        className="rounded border-gray-700 bg-gray-800 text-blue-500 focus:ring-blue-500"
                      />
                      <label htmlFor="transparent" className="text-sm text-gray-300">{t.transparent}</label>
                    </div>
                    
                    <div className={`transition-opacity ${canvasConfig.transparent ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
                      <label className="text-xs text-gray-500 mb-1 block flex items-center gap-1">
                        <Palette size={10} /> {t.backgroundColor}
                      </label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={canvasConfig.backgroundColor || '#ffffff'}
                          onChange={(e) => handleBgColorChange(e.target.value)}
                          className="h-8 w-12 bg-transparent border-0 cursor-pointer rounded overflow-hidden"
                        />
                        <input 
                          type="text" 
                          value={canvasConfig.backgroundColor || '#ffffff'}
                          onChange={(e) => handleBgColorChange(e.target.value)}
                          className="flex-1 bg-gray-900 border border-gray-600 rounded px-2 text-sm"
                        />
                      </div>
                    </div>
                </div>
              </div>

              {/* Batch Operations */}
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">{t.batchActions}</h3>
                
                {/* Duration */}
                <div className="bg-gray-800 p-3 rounded-lg border border-gray-700">
                  <label className="text-xs text-gray-500 mb-2 block">{t.setDuration}</label>
                  <div className="flex gap-2">
                    <input 
                      type="number" 
                      value={globalDuration}
                      onChange={(e) => setGlobalDuration(parseInt(e.target.value) || 100)}
                      className="flex-1 bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm"
                    />
                    <button 
                      onClick={updateGlobalDuration}
                      className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs font-medium transition-colors"
                    >
                      {t.apply}
                    </button>
                  </div>
                </div>

                {/* Auto Fit */}
                <div className="bg-gray-800 p-3 rounded-lg border border-gray-700">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs text-gray-500">{t.autoFit}</label>
                    <Scaling size={12} className="text-gray-500"/>
                  </div>
                  <div className="flex flex-col gap-2">
                      <div className="flex rounded border border-gray-600 overflow-hidden">
                        <button 
                          onClick={() => setFitMode('fill')}
                          className={`flex-1 py-1 text-xs transition-colors ${fitMode === 'fill' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800'}`}
                        >
                          {t.fitFill}
                        </button>
                        <div className="w-px bg-gray-600"></div>
                        <button 
                          onClick={() => setFitMode('contain')}
                          className={`flex-1 py-1 text-xs transition-colors ${fitMode === 'contain' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800'}`}
                        >
                          {t.fitContain}
                        </button>
                      </div>
                      <button 
                        onClick={handleAutoFit}
                        className="w-full py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs font-medium transition-colors flex items-center justify-center gap-2"
                      >
                        <Maximize size={12} /> {t.applyFit}
                      </button>
                  </div>
                </div>

                {/* Sorting */}
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => sortByFilename('asc')}
                    className="flex items-center justify-center gap-2 p-2 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 text-xs transition-colors"
                  >
                    <ArrowDownAZ size={14} /> {t.nameAsc}
                  </button>
                  <button 
                    onClick={() => sortByFilename('desc')}
                    className="flex items-center justify-center gap-2 p-2 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 text-xs transition-colors"
                  >
                    <ArrowUpAZ size={14} /> {t.nameDesc}
                  </button>
                </div>
                
                <button 
                  onClick={clearAll}
                  className={`w-full flex items-center justify-center gap-2 p-2 rounded border text-xs transition-colors ${
                    clearFramesConfirm 
                      ? 'bg-red-600 text-white border-red-500' 
                      : 'bg-red-900/20 hover:bg-red-900/40 text-red-400 border-red-900/30'
                  }`}
                >
                  {clearFramesConfirm ? <AlertCircle size={14}/> : <Trash2 size={14} />} 
                  {clearFramesConfirm ? t.confirmAction : t.removeAll}
                </button>
              </div>
            </div>
          </div>
        </aside>

        {/* Center: Split View (Canvas Editor + Frame List) */}
        <main className="flex-1 flex flex-col min-w-0 bg-gray-950">
          
          {/* Top: Canvas Editor */}
          {showCanvasEditor && (
            <div className="h-[45vh] border-b border-gray-800 flex flex-col bg-gray-900/50 relative">
               <div className="px-4 py-2 border-b border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layout size={16} className="text-blue-400" />
                    <h2 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">{t.canvasEditor}</h2>
                  </div>
                  <button 
                    onClick={() => setShowCanvasEditor(false)}
                    className="text-gray-500 hover:text-white p-1"
                    title={t.hideEditor}
                  >
                    <Minimize2 size={16} />
                  </button>
               </div>
               <CanvasEditor 
                 frame={selectedFrame}
                 frameIndex={selectedFrameIndex !== -1 ? selectedFrameIndex : undefined}
                 config={canvasConfig}
                 onUpdate={handleCanvasUpdate}
                 labels={t.frame}
                 emptyMessage={t.selectFrameToEdit}
               />
               {/* Selection Indicator Overlay */}
               {selectedFrameIds.size > 1 && (
                 <div className="absolute bottom-14 left-4 bg-blue-900/80 text-blue-200 px-3 py-1 rounded-full text-xs border border-blue-700 backdrop-blur-sm shadow-lg pointer-events-none">
                   {t.selectedFrames.replace('{count}', selectedFrameIds.size.toString())} (Batch Mode)
                 </div>
               )}
            </div>
          )}

          {/* Bottom: Frame List */}
          <div 
            className="flex-1 overflow-hidden p-0 flex flex-col"
            onContextMenu={handleBackgroundContextMenu}
            onClick={handleBackgroundClick}
          >
            <div className="flex-1 flex flex-col max-w-[1600px] mx-auto w-full h-full">
              <div className="flex items-center justify-between p-6 pb-2">
                 <h2 className="text-lg font-medium text-gray-300">
                   {t.frames} ({frames.length})
                 </h2>
                 <div className="flex items-center gap-4 text-xs text-gray-500">
                    {!showCanvasEditor && (
                       <button onClick={() => setShowCanvasEditor(true)} className="flex items-center gap-1 hover:text-blue-400">
                         <Layout size={12}/> {t.showEditor}
                       </button>
                    )}
                    <span>{t.dragReorder}</span>
                 </div>
              </div>

              {frames.length === 0 ? (
                <div className="border-2 border-dashed border-gray-800 rounded-xl h-64 flex flex-col items-center justify-center text-gray-600">
                   <p>{t.noFrames}</p>
                   <p className="text-sm">{t.uploadStart}</p>
                </div>
              ) : (
                <DndContext 
                  sensors={sensors} 
                  collisionDetection={closestCenter} 
                  onDragStart={handleDragStart}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext 
                    items={frames.map(f => f.id)} 
                    strategy={rectSortingStrategy}
                  >
                    <VirtualFrameList
                      frames={frames}
                      frameSize={frameSize}
                      compactMode={compactMode}
                      selectedFrameIds={selectedFrameIds}
                      onRemove={removeFrame}
                      onUpdate={updateFrame}
                      onSelect={handleSelection}
                      onContextMenu={handleFrameContextMenu}
                      labels={t.frame}
                    />
                  </SortableContext>
                  
                  {/* Custom Drag Overlay for Better Visuals & Multi-drag */}
                  <DragOverlay>
                    {activeDragFrame ? (
                       selectedFrameIds.has(activeDragFrame.id) && selectedFrameIds.size > 1 ? (
                         // Multi-drag Stack Visual
                         <div className="relative">
                           <div className="absolute top-2 left-2 w-full h-full bg-gray-800 border border-gray-600 rounded-lg shadow-sm rotate-3 opacity-50 z-0"></div>
                           <div className="absolute top-1 left-1 w-full h-full bg-gray-800 border border-gray-600 rounded-lg shadow-sm rotate-1 opacity-75 z-0"></div>
                           <div className="relative z-10">
                              <FrameCard
                                frame={activeDragFrame}
                                index={frames.findIndex(f => f.id === activeDragFrame.id)}
                                labels={t.frame}
                                compact={compactMode}
                                isSelected={true}
                                style={{ width: frameSize + 'px', opacity: 1, cursor: 'grabbing' }}
                              />
                           </div>
                           <div className="absolute -top-3 -right-3 bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-xs font-bold border-2 border-gray-900 shadow-xl z-20">
                             {selectedFrameIds.size}
                           </div>
                         </div>
                       ) : (
                         // Single Drag Visual
                         <div style={{ width: frameSize + 'px' }}>
                           <FrameCard
                             frame={activeDragFrame}
                             index={frames.findIndex(f => f.id === activeDragFrame.id)}
                             labels={t.frame}
                             compact={compactMode}
                             isSelected={true}
                             style={{ opacity: 1, cursor: 'grabbing', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.3)' }}
                           />
                         </div>
                       )
                    ) : null}
                  </DragOverlay>

                </DndContext>
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Context Menu */}
      {contextMenu && (
        <div 
          className="fixed z-50 bg-gray-900 border border-gray-700 shadow-xl rounded-lg py-1 w-48 overflow-hidden animate-in fade-in zoom-in-95 duration-100"
          style={{ top: contextMenu.y, left: contextMenu.x }}
        >
          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-200 hover:bg-blue-600 hover:text-white flex items-center gap-2 transition-colors"
            onClick={handleContextCopy}
          >
            <ClipboardCopy size={14} />
            {t.contextMenu.copy}
          </button>
          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-200 hover:bg-blue-600 hover:text-white flex items-center gap-2 transition-colors disabled:opacity-50 disabled:hover:bg-transparent"
            onClick={handleContextPaste}
            disabled={clipboard.length === 0}
          >
            <ClipboardPaste size={14} />
            {t.contextMenu.paste}
          </button>

          <div className="h-px bg-gray-700 my-1"></div>

          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-200 hover:bg-blue-600 hover:text-white flex items-center gap-2 transition-colors"
            onClick={handleContextDuplicate}
          >
            <Copy size={14} />
            {t.contextMenu.duplicateHere}
          </button>
          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-200 hover:bg-blue-600 hover:text-white flex items-center gap-2 transition-colors"
            onClick={handleContextInsert}
          >
            <FilePlus size={14} />
            {t.contextMenu.insertHere}
          </button>
          
          <div className="h-px bg-gray-700 my-1"></div>

          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-200 hover:bg-blue-600 hover:text-white flex items-center gap-2 transition-colors"
            onClick={handleResetFrameProperties}
          >
            <RotateCcw size={14} />
            {t.contextMenu.resetProperties}
          </button>
          
          <div className="h-px bg-gray-700 my-1"></div>
          
          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-200 hover:bg-red-600 hover:text-white flex items-center gap-2 transition-colors"
            onClick={handleContextDelete}
          >
            <Trash2 size={14} />
            {t.contextMenu.deleteSelected}
          </button>

          <div className="h-px bg-gray-700 my-1"></div>
          
          <button 
            className="w-full text-left px-4 py-2 text-sm text-gray-400 hover:bg-gray-800 hover:text-white transition-colors"
            onClick={() => setContextMenu(null)}
          >
            {t.contextMenu.cancel}
          </button>
        </div>
      )}

      {/* Insert Images Modal */}
      {showInsertModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-8">
          <div className="bg-gray-900 rounded-xl shadow-2xl max-w-md w-full border border-gray-700 flex flex-col overflow-hidden">
            <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-gray-850">
              <h3 className="font-bold text-white flex items-center gap-2">
                <Plus size={18} className="text-blue-400" />
                {t.insertModal.title}
              </h3>
              <button 
                onClick={() => setShowInsertModal(false)}
                className="text-gray-500 hover:text-white p-1"
              >
                <XIcon size={18} />
              </button>
            </div>
            <div className="p-6">
              <div 
                onClick={() => insertFileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-700 hover:border-blue-500 hover:bg-gray-800/50 rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition-all group h-48"
                onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                onDrop={handleInsertDrop}
              >
                <input 
                  type="file" 
                  multiple 
                  accept="image/*" 
                  className="hidden" 
                  ref={insertFileInputRef}
                  onChange={(e) => handleInsertFiles(e.target.files)}
                />
                <div className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <ImagePlus className="text-gray-400 group-hover:text-blue-400" size={24} />
                </div>
                <p className="text-sm font-medium text-gray-300 text-center">{t.insertModal.dropText}</p>
              </div>
            </div>
            <div className="p-4 border-t border-gray-800 bg-gray-850 flex justify-end">
              <button 
                onClick={() => setShowInsertModal(false)}
                className="px-4 py-2 text-gray-400 hover:text-white text-sm"
              >
                {t.insertModal.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Generation Modal / Overlay */}
      {(generatedGif || isGenerating) && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-8">
           <div className="bg-gray-900 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col border border-gray-700">
              <div className="p-4 border-b border-gray-800 flex justify-between items-center">
                <h3 className="font-bold text-lg">
                  {isGenerating ? t.generating : t.ready}
                </h3>
                {!isGenerating && (
                  <button 
                    onClick={() => setGeneratedGif(null)} 
                    className="p-2 hover:bg-gray-800 rounded-full text-gray-400 hover:text-white transition-colors"
                  >
                    <XIcon size={20} />
                  </button>
                )}
              </div>
              
              <div className="p-8 flex-1 overflow-auto custom-scrollbar flex items-center justify-center bg-gray-950/50 min-h-[300px]">
                {isGenerating ? (
                  <div className="text-center space-y-4">
                     <Loader2 size={48} className="animate-spin text-blue-500 mx-auto" />
                     <p className="text-xl font-light text-gray-300">{Math.round(progress)}%</p>
                     <div className="w-64 h-2 bg-gray-800 rounded-full overflow-hidden">
                       <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${progress}%` }} />
                     </div>
                  </div>
                ) : (
                  generatedGif && (
                    <img src={generatedGif} alt="Generated GIF" className="max-w-full max-h-[60vh] object-contain shadow-lg rounded border border-gray-800" />
                  )
                )}
              </div>

              {!isGenerating && generatedGif && (
                <div className="p-6 border-t border-gray-800 bg-gray-900/50 flex justify-end gap-3 rounded-b-2xl">
                   <button 
                     onClick={() => setGeneratedGif(null)}
                     className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                   >
                     {t.close}
                   </button>
                   <a 
                     href={generatedGif} 
                     download="animation.gif"
                     className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2 shadow-lg shadow-blue-900/20"
                   >
                     <Download size={18} /> {t.download}
                   </a>
                </div>
              )}
           </div>
        </div>
      )}

      {/* History Snapshots Drawer */}
      {showSnapshots && (
        <div className="absolute top-16 right-0 bottom-0 w-80 bg-gray-900 border-l border-gray-800 z-30 shadow-2xl transform transition-transform p-4 overflow-y-auto custom-scrollbar flex flex-col">
          <div className="flex justify-between items-center mb-4 shrink-0">
            <h3 className="font-bold text-white">{t.historyTitle}</h3>
            <button onClick={() => setShowSnapshots(false)} className="text-gray-500 hover:text-white"><XIcon size={24} /></button>
          </div>
          
          <div className="space-y-3 flex-1 overflow-y-auto pb-4">
             {snapshots.length === 0 && <p className="text-gray-500 text-sm italic">{t.noRecords}</p>}
             {snapshots.map(snap => (
               <div key={snap.id} className="bg-gray-800 p-3 rounded border border-gray-700 hover:border-blue-500 transition-colors group">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium text-sm text-gray-200 truncate pr-2">{snap.name}</span>
                    <button 
                      onClick={() => deleteSnapshot(snap.id)}
                      className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  
                  {/* Thumbnail */}
                  {snap.thumbnail ? (
                    <div className="mb-2 w-full h-24 bg-gray-900 rounded overflow-hidden flex items-center justify-center border border-gray-800 relative group/thumb">
                      <img src={snap.thumbnail} alt={snap.name} className="max-w-full max-h-full" />
                      <a 
                        href={snap.thumbnail}
                        download={`gif_builder_${snap.timestamp}.gif`}
                        className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover/thumb:opacity-100 transition-all duration-200"
                        title={t.download}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Download size={24} className="text-white drop-shadow-md transform scale-90 hover:scale-110 transition-transform" />
                      </a>
                    </div>
                  ) : (
                    <div className="mb-2 w-full h-12 bg-gray-900 rounded border border-gray-800 flex items-center justify-center text-xs text-gray-500">
                      ZIP Archive
                    </div>
                  )}

                  <div className="text-xs text-gray-500 mb-2">
                    {new Date(snap.timestamp).toLocaleTimeString()} • {snap.frames.length} {t.frames}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => restoreSnapshot(snap)}
                      className={`py-1.5 text-xs rounded transition-colors flex items-center justify-center gap-1 ${
                          restoreConfirmId === snap.id 
                          ? 'bg-amber-600 hover:bg-amber-500 text-white' 
                          : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                      }`}
                    >
                      {restoreConfirmId === snap.id ? <Check size={12}/> : <Undo2 size={12}/>}
                      {restoreConfirmId === snap.id ? t.confirmAction : t.restore}
                    </button>
                    <button 
                      onClick={() => handleExportZip(snap.frames)}
                      className="py-1.5 text-xs rounded bg-gray-700 hover:bg-gray-600 text-gray-300 transition-colors flex items-center justify-center gap-1"
                      title={t.downloadZip}
                    >
                      <Package size={12} /> ZIP
                    </button>
                  </div>
               </div>
             ))}
          </div>
          
          {snapshots.length > 0 && (
            <div className="pt-4 border-t border-gray-800 shrink-0">
               <button 
                 onClick={clearHistoryRecords}
                 className={`w-full py-2 rounded text-xs transition-colors flex items-center justify-center gap-2 border ${clearHistoryConfirm ? 'bg-red-600 text-white border-red-500' : 'bg-transparent text-red-500 border-red-900/30 hover:bg-red-900/20'}`}
               >
                 <Trash2 size={14} />
                 {clearHistoryConfirm ? t.confirmAction : t.clearHistory}
               </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default App;
