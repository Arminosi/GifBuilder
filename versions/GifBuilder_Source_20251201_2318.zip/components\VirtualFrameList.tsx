import React, { memo } from 'react';
import { FixedSizeList as List, areEqual } from 'react-window';
import type { ListChildComponentProps } from 'react-window';
import AutoSizer from 'react-virtualized-auto-sizer';
import { FrameData } from '../types';
import { FrameItem } from './FrameItem';
import { FrameLabels } from '../utils/translations';

interface VirtualFrameListProps {
  frames: FrameData[];
  frameSize: number;
  compactMode: boolean;
  selectedFrameIds: Set<string>;
  onRemove: (id: string) => void;
  onUpdate: (id: string, updates: Partial<FrameData>) => void;
  onSelect: (id: string, e: React.MouseEvent) => void;
  onContextMenu: (id: string, e: React.MouseEvent) => void;
  labels: FrameLabels;
}

const GAP = 16; // gap-4 (1rem)
const PADDING = 24; // p-6 (1.5rem)

const Row = memo(({ index, style, data }: ListChildComponentProps) => {
  const { 
    frames, 
    columnCount, 
    frameWidth, 
    itemHeight,
    compactMode,
    selectedFrameIds,
    onRemove,
    onUpdate,
    onSelect,
    onContextMenu,
    labels
  } = data;

  const startIndex = index * columnCount;
  // Get frames for this row
  const rowFrames = frames.slice(startIndex, startIndex + columnCount);

  return (
    <div 
      style={{
        ...style,
        paddingLeft: PADDING,
        paddingRight: PADDING,
        boxSizing: 'border-box',
      }} 
      className="flex gap-4"
    >
      {rowFrames.map((frame: FrameData, i: number) => (
        <div 
          key={frame.id} 
          style={{ 
            width: frameWidth, 
            height: itemHeight - GAP, // Subtract gap from height to maintain spacing
          }}
        >
          <FrameItem
            frame={frame}
            index={startIndex + i}
            onRemove={onRemove}
            onUpdate={onUpdate}
            labels={labels}
            compact={compactMode}
            isSelected={selectedFrameIds.has(frame.id)}
            onSelect={onSelect}
            onContextMenu={onContextMenu}
          />
        </div>
      ))}
    </div>
  );
}, areEqual);

export const VirtualFrameList: React.FC<VirtualFrameListProps> = ({
  frames,
  frameSize,
  compactMode,
  selectedFrameIds,
  onRemove,
  onUpdate,
  onSelect,
  onContextMenu,
  labels
}) => {
  
  // Estimate item height based on frameSize and mode
  // Image is square (width = frameWidth >= frameSize)
  // We use frameSize as base for height calculation, but width might be larger.
  // However, FrameItem image container is aspect-square.
  // So height grows with width.
  // This is tricky because width is dynamic.
  // We need to calculate height inside AutoSizer render prop.

  return (
    <div className="flex-1 h-full min-h-0">
      <AutoSizer>
        {({ height, width }) => {
          // Calculate columns
          const availableWidth = width - (PADDING * 2); 
          const columnCount = Math.floor((availableWidth + GAP) / (frameSize + GAP));
          const safeColumnCount = Math.max(1, columnCount);
          
          // Calculate actual width per item to fill space
          const frameWidth = (availableWidth - (safeColumnCount - 1) * GAP) / safeColumnCount;
          
          // Calculate item height based on actual width (since image is aspect-square)
          // Compact: padding/border (~20px) + header (~24px) + image (frameWidth)
          // Full: padding/border (~24px) + header (~24px) + image (frameWidth) + inputs (~140px)
          const itemHeight = compactMode 
            ? frameWidth + 60 
            : frameWidth + 220; 

          const rowCount = Math.ceil(frames.length / safeColumnCount);

          return (
            <List
              height={height}
              itemCount={rowCount}
              itemSize={itemHeight}
              width={width}
              className="custom-scrollbar"
              itemData={{
                frames,
                columnCount: safeColumnCount,
                frameWidth,
                itemHeight,
                compactMode,
                selectedFrameIds,
                onRemove,
                onUpdate,
                onSelect,
                onContextMenu,
                labels
              }}
            >
              {Row}
            </List>
          );
        }}
      </AutoSizer>
    </div>
  );
};
