
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { FrameData, CanvasConfig } from '../types';
import { FrameLabels } from '../utils/translations';
import { Move, ZoomIn, ZoomOut, Maximize } from 'lucide-react';

interface CanvasEditorProps {
  frame: FrameData | null;
  frameIndex?: number;
  config: CanvasConfig;
  onUpdate: (updates: Partial<FrameData>, commit: boolean) => void;
  labels: FrameLabels;
  emptyMessage: string;
}

type InteractionMode = 'idle' | 'move' | 'resize-tl' | 'resize-tr' | 'resize-bl' | 'resize-br';

interface InteractionState {
  mode: InteractionMode;
  startPointerX: number;
  startPointerY: number;
  startFrameX: number;
  startFrameY: number;
  startFrameW: number;
  startFrameH: number;
  ratio: number;
  hasCommitted: boolean;
}

export const CanvasEditor: React.FC<CanvasEditorProps> = ({ frame, frameIndex, config, onUpdate, labels, emptyMessage }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [isAutoFit, setIsAutoFit] = useState(true);
  const [interaction, setInteraction] = useState<InteractionState | null>(null);

  // Auto-scale canvas to fit container
  const fitToContainer = useCallback(() => {
    if (!containerRef.current) return;
    const { width: containerWidth, height: containerHeight } = containerRef.current.getBoundingClientRect();
    // Leave some padding
    const padding = 40;
    const availableW = containerWidth - padding;
    const availableH = containerHeight - padding;
    
    const scaleW = availableW / config.width;
    const scaleH = availableH / config.height;
    
    setScale(Math.min(scaleW, scaleH, 1.5)); // Max scale 1.5
  }, [config.width, config.height]);

  useEffect(() => {
    if (isAutoFit) {
      fitToContainer();
    }
  }, [isAutoFit, fitToContainer]);

  useEffect(() => {
    if (!isAutoFit) return;
    window.addEventListener('resize', fitToContainer);
    return () => window.removeEventListener('resize', fitToContainer);
  }, [isAutoFit, fitToContainer]);

  const handleZoomIn = () => {
    setIsAutoFit(false);
    setScale(prev => Math.min(prev + 0.1, 5));
  };

  const handleZoomOut = () => {
    setIsAutoFit(false);
    setScale(prev => Math.max(prev - 0.1, 0.1));
  };

  const handleResetZoom = () => {
    setIsAutoFit(true);
  };

  // Handle Pointer Events
  const handlePointerDown = (e: React.PointerEvent, mode: InteractionMode) => {
    if (!frame) return;
    e.preventDefault();
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);

    setInteraction({
      mode,
      startPointerX: e.clientX,
      startPointerY: e.clientY,
      startFrameX: frame.x,
      startFrameY: frame.y,
      startFrameW: frame.width,
      startFrameH: frame.height,
      ratio: frame.width / frame.height || 1,
      hasCommitted: false
    });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!interaction) return;
    e.preventDefault();

    const { 
      mode, 
      startPointerX, startPointerY, 
      startFrameX, startFrameY, startFrameW, startFrameH, 
      ratio 
    } = interaction;

    // Calculate raw displacement from start (in canvas units)
    const dx = (e.clientX - startPointerX) / scale;
    const dy = (e.clientY - startPointerY) / scale;

    const isShift = e.shiftKey;
    const isAlt = e.altKey;

    let newX = startFrameX;
    let newY = startFrameY;
    let newW = startFrameW;
    let newH = startFrameH;

    if (mode === 'move') {
      newX += dx;
      newY += dy;
    } else {
      // Resize Logic
      
      // Determine direction of growth based on corner
      // 1 means growing in + direction (Right/Bottom)
      // -1 means growing in - direction (Left/Top)
      let dirX = 0;
      let dirY = 0;

      if (mode.includes('l')) dirX = -1;
      if (mode.includes('r')) dirX = 1;
      if (mode.includes('t')) dirY = -1;
      if (mode.includes('b')) dirY = 1;

      // Unconstrained new dimensions logic
      // If Alt (Center), movement maps to double the size change because the opposite side moves symmetrically
      const sizeMult = isAlt ? 2 : 1;
      
      let targetW = startFrameW + (dx * dirX * sizeMult);
      let targetH = startFrameH + (dy * dirY * sizeMult);

      // Apply Shift (Aspect Ratio)
      if (isShift) {
        // Heuristic: Use the dimension that changed most relative to its size (or just absolute change)
        const absDeltaW = Math.abs(targetW - startFrameW);
        const absDeltaH = Math.abs(targetH - startFrameH);
        
        // Normalize using original aspect ratio to decide dominant axis
        if (absDeltaW / startFrameW > absDeltaH / startFrameH) {
           targetH = targetW / ratio;
        } else {
           targetW = targetH * ratio;
        }
      }

      newW = Math.max(1, targetW); 
      newH = Math.max(1, targetH);

      // Calculate Position (X, Y)
      if (isAlt) {
        // Center scaling: Center point remains constant
        const centerX = startFrameX + startFrameW / 2;
        const centerY = startFrameY + startFrameH / 2;
        newX = centerX - newW / 2;
        newY = centerY - newH / 2;
      } else {
        // Standard Corner Resize
        // If growing Right (dirX=1), X stays same.
        // If growing Left (dirX=-1), X moves by the difference in width (anchored right)
        if (dirX === -1) {
           newX = startFrameX + (startFrameW - newW);
        } else {
           newX = startFrameX;
        }

        if (dirY === -1) {
           newY = startFrameY + (startFrameH - newH);
        } else {
           newY = startFrameY;
        }
      }
    }

    // Calculate Updates to send to App
    // We compare calculated Target vs Current Frame Props to see if update is needed
    // But we send the ABSOLUTE target values, not deltas, to prevent accumulation errors
    if (!frame) return;

    const updates: Partial<FrameData> = {};
    
    // Check if values have changed significantly enough to warrant an update
    if (Math.round(newX) !== Math.round(frame.x)) updates.x = newX;
    if (Math.round(newY) !== Math.round(frame.y)) updates.y = newY;
    if (Math.round(newW) !== Math.round(frame.width)) updates.width = newW;
    if (Math.round(newH) !== Math.round(frame.height)) updates.height = newH;

    if (Object.keys(updates).length > 0) {
       const shouldCommit = !interaction.hasCommitted;
       onUpdate(updates, shouldCommit);
       
       if (shouldCommit) {
         setInteraction(prev => prev ? { ...prev, hasCommitted: true } : null);
       }
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (interaction) {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      setInteraction(null);
    }
  };

  if (!frame) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-900 border-b border-gray-800 text-gray-500 text-sm">
        {emptyMessage}
      </div>
    );
  }

  const canvasStyle = {
    width: config.width * scale,
    height: config.height * scale,
    backgroundColor: config.transparent ? 'transparent' : (config.backgroundColor || '#ffffff'),
    backgroundImage: config.transparent ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)' : 'none',
    backgroundSize: '20px 20px',
    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
  };

  const frameStyle = {
    left: frame.x * scale,
    top: frame.y * scale,
    width: frame.width * scale,
    height: frame.height * scale,
  };

  return (
    <div 
      ref={containerRef} 
      className="flex-1 bg-gray-950 relative overflow-hidden flex items-center justify-center p-8 select-none"
    >
      {/* Canvas Area */}
      <div 
        className="relative shadow-2xl box-content border border-gray-700" 
        style={canvasStyle}
      >
        {/* Frame Image */}
        <div 
          className="absolute group cursor-move"
          style={frameStyle}
          onPointerDown={(e) => handlePointerDown(e, 'move')}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
        >
          <img 
            src={frame.previewUrl} 
            alt="frame" 
            className="w-full h-full object-fill pointer-events-none" 
          />
          
          {/* Border Highlight */}
          <div className="absolute inset-0 border-2 border-blue-500 pointer-events-none" />

          {/* Resize Handles */}
          {[
            { mode: 'resize-tl', pos: '-top-1.5 -left-1.5 cursor-nw-resize' },
            { mode: 'resize-tr', pos: '-top-1.5 -right-1.5 cursor-ne-resize' },
            { mode: 'resize-bl', pos: '-bottom-1.5 -left-1.5 cursor-sw-resize' },
            { mode: 'resize-br', pos: '-bottom-1.5 -right-1.5 cursor-se-resize' },
          ].map((h) => (
            <div
              key={h.mode}
              className={`absolute w-3 h-3 bg-white border border-blue-600 rounded-full z-20 ${h.pos} hover:scale-125 transition-transform`}
              onPointerDown={(e) => handlePointerDown(e, h.mode as InteractionMode)}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
            />
          ))}
          
          {/* Center Move Handle (Icon) */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 pointer-events-none">
             <Move size={24} className="text-white drop-shadow-md" />
          </div>

        </div>
      </div>
      
      {/* Persistent Frame Stats Bar */}
      <div className="absolute bottom-4 left-4 flex gap-3 text-xs text-gray-300 bg-gray-900/90 px-3 py-2 rounded-lg backdrop-blur-sm border border-gray-700 shadow-lg pointer-events-none z-20">
        {frameIndex !== undefined && (
          <>
            <div className="flex gap-1.5 items-center">
              <span className="text-gray-500 font-medium">#</span>
              <span className="font-mono">{frameIndex + 1}</span>
            </div>
            <div className="w-px h-3 bg-gray-700 my-auto"></div>
          </>
        )}
        <div className="flex gap-1.5 items-center">
          <span className="text-gray-500 font-medium">{labels.time}</span>
          <span className="font-mono">{frame.duration}ms</span>
        </div>
        <div className="w-px h-3 bg-gray-700 my-auto"></div>
        <div className="flex gap-1.5 items-center">
          <span className="text-gray-500 font-medium">{labels.x}</span>
          <span className="font-mono">{Math.round(frame.x)}</span>
        </div>
        <div className="w-px h-3 bg-gray-700 my-auto"></div>
        <div className="flex gap-1.5 items-center">
          <span className="text-gray-500 font-medium">{labels.y}</span>
          <span className="font-mono">{Math.round(frame.y)}</span>
        </div>
        <div className="w-px h-3 bg-gray-700 my-auto"></div>
        <div className="flex gap-1.5 items-center">
          <span className="text-gray-500 font-medium">{labels.w}</span>
          <span className="font-mono">{Math.round(frame.width)}</span>
        </div>
        <div className="w-px h-3 bg-gray-700 my-auto"></div>
        <div className="flex gap-1.5 items-center">
          <span className="text-gray-500 font-medium">{labels.h}</span>
          <span className="font-mono">{Math.round(frame.height)}</span>
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-gray-900/90 p-1.5 rounded-lg backdrop-blur-sm border border-gray-700 shadow-lg z-20">
        <button 
          onClick={handleZoomOut}
          className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-white transition-colors"
          title="Zoom Out"
        >
          <ZoomOut size={14} />
        </button>
        
        <span className="text-xs font-mono text-gray-300 w-12 text-center select-none">
          {Math.round(scale * 100)}%
        </span>

        <button 
          onClick={handleZoomIn}
          className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-white transition-colors"
          title="Zoom In"
        >
          <ZoomIn size={14} />
        </button>

        <div className="w-px h-4 bg-gray-700 mx-1"></div>

        <button 
          onClick={handleResetZoom}
          className={`p-1 rounded transition-colors ${isAutoFit ? 'text-blue-400 bg-blue-900/30' : 'text-gray-400 hover:bg-gray-700 hover:text-white'}`}
          title="Auto Fit"
        >
          <Maximize size={14} />
        </button>
      </div>
    </div>
  );
};
