

export type Language = 'en' | 'zh';

export interface FrameLabels {
  time: string;
  x: string;
  y: string;
  w: string;
  h: string;
}

export interface TranslationSchema {
  undo: string;
  redo: string;
  records: string;
  generate: string;
  dropHere: string;
  clickDrag: string;
  supports: string;
  canvasSettings: string;
  width: string;
  height: string;
  transparent: string;
  backgroundColor: string;
  batchActions: string;
  autoFit: string;
  fitMode: string;
  fitFill: string;
  fitContain: string;
  applyFit: string;
  setDuration: string;
  apply: string;
  nameAsc: string;
  nameDesc: string;
  removeAll: string;
  saveHistory: string;
  frames: string;
  dragReorder: string;
  noFrames: string;
  uploadStart: string;
  generating: string;
  ready: string;
  close: string;
  download: string;
  historyTitle: string;
  noRecords: string;
  restore: string;
  confirmClear: string;
  promptSave: string;
  confirmRestore: string;
  failed: string;
  viewOptions: string;
  frameSize: string;
  compactMode: string;
  autoSaved: string;
  clearHistory: string;
  confirmClearHistory: string;
  confirmAction: string;
  toggleSidebar: string;
  canvasEditor: string;
  selectFrameToEdit: string;
  frame: FrameLabels;
  selectedFrames: string;
  selectionProperties: string;
  showEditor: string;
  hideEditor: string;
  batchMove: string;
  exportZip: string;
  zipping: string;
  downloadZip: string;
  zipSaved: string;
  duplicate: string;
  duplicateShortcut: string;
  resetProperties: string;
  contextMenu: {
    copy: string;
    paste: string;
    duplicateHere: string;
    insertHere: string;
    resetProperties: string;
    deleteSelected: string;
    cancel: string;
  };
  insertModal: {
    title: string;
    dropText: string;
    cancel: string;
  };
}

export const translations: Record<Language, TranslationSchema> = {
  en: {
    undo: "Undo (Ctrl+Z)",
    redo: "Redo (Ctrl+Y)",
    records: "History",
    generate: "Generate GIF",
    dropHere: "Drop images here",
    clickDrag: "Click or Drag images",
    supports: "Supports PNG, JPG, WEBP",
    canvasSettings: "Canvas Settings",
    width: "Width (px)",
    height: "Height (px)",
    transparent: "Transparent Background",
    backgroundColor: "Background Color",
    batchActions: "Batch Actions",
    autoFit: "Auto Fit Frames",
    fitMode: "Fit Mode",
    fitFill: "Stretch / Fill",
    fitContain: "Keep Ratio / Contain",
    applyFit: "Resize All Frames",
    setDuration: "Set all duration (ms)",
    apply: "Apply",
    nameAsc: "Name Asc",
    nameDesc: "Name Desc",
    removeAll: "Remove All Frames",
    saveHistory: "Save Snapshot",
    frames: "Frames",
    dragReorder: "Drag to reorder",
    noFrames: "No frames yet.",
    uploadStart: "Upload images to get started.",
    generating: "Generating GIF...",
    ready: "GIF Ready!",
    close: "Close",
    download: "Download GIF",
    historyTitle: "Snapshots",
    noRecords: "No saved snapshots.",
    restore: "Restore",
    confirmClear: "Are you sure you want to clear all frames?",
    promptSave: "Enter a name for this history record:",
    confirmRestore: "Restore snapshot \"{name}\"? Current unsaved changes will be lost.",
    failed: "Failed to generate GIF. See console for details.",
    viewOptions: "View Options",
    frameSize: "Frame Size",
    compactMode: "Compact Mode",
    autoSaved: "Auto-save",
    clearHistory: "Clear History",
    confirmClearHistory: "Click again to confirm",
    confirmAction: "Click again to confirm",
    toggleSidebar: "Toggle Sidebar",
    canvasEditor: "Canvas Editor",
    selectFrameToEdit: "Select a frame from the list below to edit its position and size.",
    frame: {
      time: "Time (ms)",
      x: "X Pos",
      y: "Y Pos",
      w: "Width",
      h: "Height"
    },
    selectedFrames: "{count} Frames Selected",
    selectionProperties: "Selection Properties",
    showEditor: "Show Editor",
    hideEditor: "Hide Editor",
    batchMove: "Batch Move",
    exportZip: "Package ZIP",
    zipping: "Zipping...",
    downloadZip: "Download Source ZIP",
    zipSaved: "Auto-save (ZIP)",
    duplicate: "Duplicate Selected",
    duplicateShortcut: "Duplicate (Ctrl+D)",
    resetProperties: "Reset Properties",
    contextMenu: {
      copy: "Copy (Ctrl+C)",
      paste: "Paste (Ctrl+V)",
      duplicateHere: "Duplicate Selected Here",
      insertHere: "Insert Images Here",
      resetProperties: "Reset Properties",
      deleteSelected: "Delete Selected",
      cancel: "Cancel"
    },
    insertModal: {
      title: "Insert Images",
      dropText: "Drag & Drop or Click to Insert",
      cancel: "Cancel"
    }
  },
  zh: {
    undo: "撤销 (Ctrl+Z)",
    redo: "重做 (Ctrl+Y)",
    records: "历史存档",
    generate: "生成 GIF",
    dropHere: "拖放图片到此处",
    clickDrag: "点击或拖拽上传图片",
    supports: "支持 PNG, JPG, WEBP",
    canvasSettings: "画布设置",
    width: "宽度 (px)",
    height: "高度 (px)",
    transparent: "透明背景",
    backgroundColor: "背景颜色",
    batchActions: "批量操作",
    autoFit: "自动缩放",
    fitMode: "缩放模式",
    fitFill: "填充 / 拉伸",
    fitContain: "保持比例 / 适应",
    applyFit: "应用缩放",
    setDuration: "统一设置时长 (ms)",
    apply: "应用",
    nameAsc: "文件名正序",
    nameDesc: "文件名倒序",
    removeAll: "清空所有帧",
    saveHistory: "保存快照",
    frames: "帧列表",
    dragReorder: "拖拽可重新排序",
    noFrames: "暂无图片帧",
    uploadStart: "上传图片开始制作",
    generating: "正在生成 GIF...",
    ready: "GIF 制作完成!",
    close: "关闭",
    download: "下载 GIF",
    historyTitle: "历史快照",
    noRecords: "暂无历史记录",
    restore: "恢复",
    confirmClear: "确定要清空所有帧吗？",
    promptSave: "请输入此记录的名称:",
    confirmRestore: "确定恢复存档 \"{name}\" 吗？当前未保存的更改将丢失。",
    failed: "生成 GIF 失败，请查看控制台。",
    viewOptions: "视图选项",
    frameSize: "图标大小",
    compactMode: "紧凑模式",
    autoSaved: "自动保存",
    clearHistory: "清空历史",
    confirmClearHistory: "再次点击确认清空",
    confirmAction: "再次点击确认",
    toggleSidebar: "切换侧边栏",
    canvasEditor: "画布编辑",
    selectFrameToEdit: "在下方列表中选择一帧以编辑其位置和大小。",
    frame: {
      time: "时长 (ms)",
      x: "X 坐标",
      y: "Y 坐标",
      w: "宽度",
      h: "高度"
    },
    selectedFrames: "已选择 {count} 帧",
    selectionProperties: "选中帧属性",
    showEditor: "显示编辑器",
    hideEditor: "隐藏编辑器",
    batchMove: "批量移动",
    exportZip: "打包下载",
    zipping: "正在打包...",
    downloadZip: "下载原图压缩包",
    zipSaved: "自动保存 (ZIP)",
    duplicate: "复制选中帧",
    duplicateShortcut: "复制 (Ctrl+D)",
    resetProperties: "重置属性",
    contextMenu: {
      copy: "复制 (Ctrl+C)",
      paste: "粘贴 (Ctrl+V)",
      duplicateHere: "复制选中帧到此处",
      insertHere: "插入图片到此处",
      resetProperties: "重置选中帧属性",
      deleteSelected: "删除选中帧",
      cancel: "取消"
    },
    insertModal: {
      title: "插入图片",
      dropText: "拖拽或点击以上传插入",
      cancel: "取消"
    }
  }
};