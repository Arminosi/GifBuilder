
import { FrameData, CanvasConfig } from '../types';
import GIF from 'gif.js';

// Cache the worker blob URL to avoid fetching it every time
let workerBlobUrl: string | null = null;

const getWorkerUrl = async (): Promise<string> => {
  if (workerBlobUrl) return workerBlobUrl;
  
  try {
    const response = await fetch('https://unpkg.com/gif.js@0.2.0/dist/gif.worker.js');
    if (!response.ok) throw new Error('Network response was not ok');
    const scriptContent = await response.text();
    const blob = new Blob([scriptContent], { type: 'application/javascript' });
    workerBlobUrl = URL.createObjectURL(blob);
    return workerBlobUrl;
  } catch (error) {
    console.error("Failed to load local worker script, falling back to CDN", error);
    // Fallback if fetch fails, though likely to fail with same security error
    return 'https://unpkg.com/gif.js@0.2.0/dist/gif.worker.js';
  }
};

export const generateGIF = async (
  frames: FrameData[],
  config: CanvasConfig,
  onProgress: (progress: number) => void
): Promise<Blob> => {
  
  // Load worker script before starting
  const workerScript = await getWorkerUrl();

  return new Promise((resolve, reject) => {
    if (frames.length === 0) {
      reject(new Error("No frames to generate"));
      return;
    }

    const gif = new GIF({
      workers: 2,
      quality: config.quality,
      width: config.width,
      height: config.height,
      workerScript: workerScript,
      repeat: config.repeat,
      transparent: config.transparent,
      background: config.transparent ? undefined : config.backgroundColor // Use bg color for gif.js optimization if not transparent
    });

    gif.on('progress', (p) => {
      onProgress(p);
    });

    gif.on('finished', (blob) => {
      resolve(blob);
    });

    // Helper to load image
    const loadImage = (url: string): Promise<HTMLImageElement> => {
      return new Promise((r, e) => {
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.onload = () => r(img);
        img.onerror = e;
        img.src = url;
      });
    };

    // Process frames sequentially to ensure order (though addFrame is synchronous usually, loading images is async)
    const processFrames = async () => {
      const canvas = document.createElement('canvas');
      canvas.width = config.width;
      canvas.height = config.height;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (!ctx) {
        reject(new Error("Could not create canvas context"));
        return;
      }

      for (const frame of frames) {
        try {
          const img = await loadImage(frame.previewUrl);
          
          // Clear canvas
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          
          // Fill background if not transparent
          if (!config.transparent) {
             ctx.fillStyle = config.backgroundColor || '#ffffff';
             ctx.fillRect(0, 0, canvas.width, canvas.height);
          }

          // Draw image at specified position and size
          if (frame.rotation) {
            ctx.save();
            // Translate to center of image
            const cx = frame.x + frame.width / 2;
            const cy = frame.y + frame.height / 2;
            ctx.translate(cx, cy);
            ctx.rotate((frame.rotation * Math.PI) / 180);
            
            // If rotated 90 or 270, swap dimensions to match the visual bounding box
            if (Math.abs(frame.rotation % 180) === 90) {
               ctx.drawImage(img, -frame.height / 2, -frame.width / 2, frame.height, frame.width);
            } else {
               ctx.drawImage(img, -frame.width / 2, -frame.height / 2, frame.width, frame.height);
            }
            ctx.restore();
          } else {
            ctx.drawImage(img, frame.x, frame.y, frame.width, frame.height);
          }

          gif.addFrame(ctx, {
            copy: true,
            delay: frame.duration
          });
        } catch (error) {
          console.error("Error loading frame image:", error);
        }
      }

      gif.render();
    };

    processFrames().catch(reject);
  });
};
