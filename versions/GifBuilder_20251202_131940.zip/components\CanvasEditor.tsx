import React, { useRef, useState, useEffect, useCallback } from 'react';
import { FrameData, CanvasConfig } from '../types';
import { FrameLabels } from '../utils/translations';
import { Move, ZoomIn, ZoomOut, Maximize, Lock, Unlock, Magnet, Info, ChevronLeft } from 'lucide-react';

interface CanvasEditorProps {
  frame: FrameData | null;
  frameIndex?: number;
  config: CanvasConfig;
  onUpdate: (updates: Partial<FrameData>, commit: boolean) => void;
  labels: FrameLabels & { frameInfo: string };
  emptyMessage: string;
}

type InteractionMode = 'idle' | 'move' | 'resize-tl' | 'resize-tr' | 'resize-bl' | 'resize-br';

interface InteractionState {
  mode: InteractionMode;
  startPointerX: number;
  startPointerY: number;
  startFrameX: number;
  startFrameY: number;
  startFrameW: number;
  startFrameH: number;
  ratio: number;
  hasCommitted: boolean;
}

const EditableStat = ({ 
  label, 
  value, 
  unit = '', 
  onChange 
}: { 
  label: string; 
  value: number; 
  unit?: string; 
  onChange: (val: number) => void; 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localValue, setLocalValue] = useState(value.toString());
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setLocalValue(value.toString());
  }, [value]);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const commit = () => {
    setIsEditing(false);
    const num = parseInt(localValue);
    if (!isNaN(num) && num !== value) {
      onChange(num);
    } else {
      setLocalValue(value.toString());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      commit();
    } else if (e.key === 'Escape') {
      setIsEditing(false);
      setLocalValue(value.toString());
    }
  };

  if (isEditing) {
    return (
      <div className="flex gap-1.5 items-center pointer-events-auto" onClick={(e) => e.stopPropagation()}>
        <span className="text-gray-500 font-medium">{label}</span>
        <input
          ref={inputRef}
          type="number"
          value={localValue}
          onChange={(e) => setLocalValue(e.target.value)}
          onBlur={commit}
          onKeyDown={handleKeyDown}
          className="w-16 bg-gray-800 border border-blue-500 rounded px-1 py-0 text-xs text-white focus:outline-none"
        />
        {unit && <span className="text-gray-500">{unit}</span>}
      </div>
    );
  }

  return (
    <div 
      className="flex gap-1.5 items-center cursor-pointer hover:bg-gray-800/50 rounded px-1 -mx-1 transition-colors group/stat pointer-events-auto"
      onClick={(e) => {
        e.stopPropagation();
        setIsEditing(true);
      }}
      title="Click to edit"
    >
      <span className="text-gray-500 font-medium">{label}</span>
      <span className="font-mono border-b border-dashed border-gray-600 group-hover/stat:border-blue-400 transition-colors">{value}{unit}</span>
    </div>
  );
};

export const CanvasEditor: React.FC<CanvasEditorProps> = ({ frame, frameIndex, config, onUpdate, labels, emptyMessage }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [isAutoFit, setIsAutoFit] = useState(true);
  const [keepAspectRatio, setKeepAspectRatio] = useState(false);
  const [snapToGrid, setSnapToGrid] = useState(false);
  const [isStatsExpanded, setIsStatsExpanded] = useState(false);
  const [interaction, setInteraction] = useState<InteractionState | null>(null);

  // Auto-scale canvas to fit container
  const fitToContainer = useCallback(() => {
    if (!containerRef.current) return;
    const { width: containerWidth, height: containerHeight } = containerRef.current.getBoundingClientRect();
    
    // If container is hidden or too small, don't update scale to invalid values
    if (containerWidth === 0 || containerHeight === 0) return;

    // Leave some padding
    const padding = 40;
    const availableW = Math.max(50, containerWidth - padding);
    const availableH = Math.max(50, containerHeight - padding);
    
    const scaleW = availableW / (config.width || 1);
    const scaleH = availableH / (config.height || 1);
    
    // Ensure scale is positive and reasonable
    setScale(Math.max(0.05, Math.min(scaleW, scaleH, 1.5))); 
  }, [config.width, config.height]);

  useEffect(() => {
    if (!isAutoFit || !containerRef.current) return;

    const resizeObserver = new ResizeObserver(() => {
      window.requestAnimationFrame(() => {
        fitToContainer();
      });
    });

    resizeObserver.observe(containerRef.current);
    
    // Initial fit
    fitToContainer();

    return () => resizeObserver.disconnect();
  }, [isAutoFit, fitToContainer]);

  const handleZoomIn = () => {
    setIsAutoFit(false);
    setScale(prev => Math.min(prev + 0.1, 5));
  };

  const handleZoomOut = () => {
    setIsAutoFit(false);
    setScale(prev => Math.max(prev - 0.1, 0.1));
  };

  const handleResetZoom = () => {
    setIsAutoFit(true);
  };

  // Handle Pointer Events
  const handlePointerDown = (e: React.PointerEvent, mode: InteractionMode) => {
    if (!frame) return;
    e.preventDefault();
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);

    setInteraction({
      mode,
      startPointerX: e.clientX,
      startPointerY: e.clientY,
      startFrameX: frame.x,
      startFrameY: frame.y,
      startFrameW: frame.width,
      startFrameH: frame.height,
      ratio: frame.width / frame.height || 1,
      hasCommitted: false
    });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!interaction) return;
    e.preventDefault();

    const { 
      mode, 
      startPointerX, startPointerY, 
      startFrameX, startFrameY, startFrameW, startFrameH, 
      ratio 
    } = interaction;

    // Calculate raw displacement from start (in canvas units)
    const dx = (e.clientX - startPointerX) / scale;
    const dy = (e.clientY - startPointerY) / scale;

    const isShift = e.shiftKey || keepAspectRatio;
    const isAlt = e.altKey;

    let newX = startFrameX;
    let newY = startFrameY;
    let newW = startFrameW;
    let newH = startFrameH;

    const SNAP_THRESHOLD = 10 / scale;

    if (mode === 'move') {
      newX += dx;
      newY += dy;

      if (snapToGrid) {
        // Snap Left/Right
        if (Math.abs(newX) < SNAP_THRESHOLD) newX = 0;
        if (Math.abs(newX + newW - config.width) < SNAP_THRESHOLD) newX = config.width - newW;
        if (Math.abs(newX + newW / 2 - config.width / 2) < SNAP_THRESHOLD) newX = config.width / 2 - newW / 2;

        // Snap Top/Bottom
        if (Math.abs(newY) < SNAP_THRESHOLD) newY = 0;
        if (Math.abs(newY + newH - config.height) < SNAP_THRESHOLD) newY = config.height - newH;
        if (Math.abs(newY + newH / 2 - config.height / 2) < SNAP_THRESHOLD) newY = config.height / 2 - newH / 2;
      }
    } else {
      // Resize Logic
      
      // Determine direction of growth based on corner
      // 1 means growing in + direction (Right/Bottom)
      // -1 means growing in - direction (Left/Top)
      let dirX = 0;
      let dirY = 0;

      if (mode.includes('l')) dirX = -1;
      if (mode.includes('r')) dirX = 1;
      if (mode.includes('t')) dirY = -1;
      if (mode.includes('b')) dirY = 1;

      // Unconstrained new dimensions logic
      // If Alt (Center), movement maps to double the size change because the opposite side moves symmetrically
      const sizeMult = isAlt ? 2 : 1;
      
      let targetW = startFrameW + (dx * dirX * sizeMult);
      let targetH = startFrameH + (dy * dirY * sizeMult);

      // Snap Logic for Resize
      if (snapToGrid && !isAlt) {
          if (dirX === 1) { // Right Edge
             if (Math.abs((startFrameX + targetW) - config.width) < SNAP_THRESHOLD) targetW = config.width - startFrameX;
          } else if (dirX === -1) { // Left Edge
             if (Math.abs((startFrameX + startFrameW - targetW) - 0) < SNAP_THRESHOLD) targetW = startFrameX + startFrameW;
          }

          if (dirY === 1) { // Bottom Edge
             if (Math.abs((startFrameY + targetH) - config.height) < SNAP_THRESHOLD) targetH = config.height - startFrameY;
          } else if (dirY === -1) { // Top Edge
             if (Math.abs((startFrameY + startFrameH - targetH) - 0) < SNAP_THRESHOLD) targetH = startFrameY + startFrameH;
          }
      }

      // Apply Shift (Aspect Ratio)
      if (isShift) {
        // Heuristic: Use the dimension that changed most relative to its size (or just absolute change)
        const absDeltaW = Math.abs(targetW - startFrameW);
        const absDeltaH = Math.abs(targetH - startFrameH);
        
        // Normalize using original aspect ratio to decide dominant axis
        if (absDeltaW / startFrameW > absDeltaH / startFrameH) {
           targetH = targetW / ratio;
        } else {
           targetW = targetH * ratio;
        }
      }

      newW = Math.max(1, targetW); 
      newH = Math.max(1, targetH);

      // Calculate Position (X, Y)
      if (isAlt) {
        // Center scaling: Center point remains constant
        const centerX = startFrameX + startFrameW / 2;
        const centerY = startFrameY + startFrameH / 2;
        newX = centerX - newW / 2;
        newY = centerY - newH / 2;
      } else {
        // Standard Corner Resize
        // If growing Right (dirX=1), X stays same.
        // If growing Left (dirX=-1), X moves by the difference in width (anchored right)
        if (dirX === -1) {
           newX = startFrameX + (startFrameW - newW);
        } else {
           newX = startFrameX;
        }

        if (dirY === -1) {
           newY = startFrameY + (startFrameH - newH);
        } else {
           newY = startFrameY;
        }
      }
    }

    // Calculate Updates to send to App
    // We compare calculated Target vs Current Frame Props to see if update is needed
    // But we send the ABSOLUTE target values, not deltas, to prevent accumulation errors
    if (!frame) return;

    const updates: Partial<FrameData> = {};
    
    // Check if values have changed significantly enough to warrant an update
    if (Math.round(newX) !== Math.round(frame.x)) updates.x = newX;
    if (Math.round(newY) !== Math.round(frame.y)) updates.y = newY;
    if (Math.round(newW) !== Math.round(frame.width)) updates.width = newW;
    if (Math.round(newH) !== Math.round(frame.height)) updates.height = newH;

    if (Object.keys(updates).length > 0) {
       const shouldCommit = !interaction.hasCommitted;
       onUpdate(updates, shouldCommit);
       
       if (shouldCommit) {
         setInteraction(prev => prev ? { ...prev, hasCommitted: true } : null);
       }
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (interaction) {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      setInteraction(null);
    }
  };

  if (!frame) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-900 border-b border-gray-800 text-gray-500 text-sm">
        {emptyMessage}
      </div>
    );
  }

  const canvasStyle = {
    width: config.width * scale,
    height: config.height * scale,
    backgroundColor: config.transparent ? 'transparent' : (config.backgroundColor || '#ffffff'),
    backgroundImage: config.transparent ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)' : 'none',
    backgroundSize: '20px 20px',
    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
  };

  const frameStyle = {
    left: frame.x * scale,
    top: frame.y * scale,
    width: frame.width * scale,
    height: frame.height * scale,
  };

  return (
    <div 
      ref={containerRef} 
      className="flex-1 bg-gray-950 relative overflow-hidden flex items-center justify-center p-8 select-none touch-none"
    >
      {/* Canvas Area */}
      <div 
        className="relative shadow-2xl box-content border border-gray-700" 
        style={canvasStyle}
      >
        {/* Frame Image */}
        <div 
          className="absolute group cursor-move touch-none"
          style={frameStyle}
          onPointerDown={(e) => handlePointerDown(e, 'move')}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
        >
          <img 
            src={frame.previewUrl} 
            alt="frame" 
            className="w-full h-full object-fill pointer-events-none" 
          />
          
          {/* Border Highlight */}
          <div className="absolute inset-0 border-2 border-blue-500 pointer-events-none" />

          {/* Resize Handles */}
          {[
            { mode: 'resize-tl', pos: '-top-4 -left-4 cursor-nw-resize' },
            { mode: 'resize-tr', pos: '-top-4 -right-4 cursor-ne-resize' },
            { mode: 'resize-bl', pos: '-bottom-4 -left-4 cursor-sw-resize' },
            { mode: 'resize-br', pos: '-bottom-4 -right-4 cursor-se-resize' },
          ].map((h) => (
            <div
              key={h.mode}
              className={`absolute w-8 h-8 flex items-center justify-center z-20 ${h.pos} touch-none`}
              onPointerDown={(e) => handlePointerDown(e, h.mode as InteractionMode)}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
            >
              <div className="w-3 h-3 bg-white border border-blue-600 rounded-full hover:scale-125 transition-transform shadow-sm" />
            </div>
          ))}
          
          {/* Center Move Handle (Icon) */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 pointer-events-none">
             <Move size={24} className="text-white drop-shadow-md" />
          </div>

        </div>
      </div>
      
      {/* Persistent Frame Stats Bar */}
      <div 
        onClick={() => setIsStatsExpanded(!isStatsExpanded)}
        className={`
          absolute z-20 bg-gray-900/90 backdrop-blur-sm border border-gray-700 shadow-lg text-xs text-gray-300 transition-all
          flex flex-col rounded-r-lg border-l-0 cursor-pointer pointer-events-auto
          ${isStatsExpanded ? 'p-3 gap-2 min-w-[120px]' : 'p-2 gap-0'}
          
          /* Mobile: Bottom Left */
          left-0 bottom-4 top-auto translate-y-0
          
          /* Desktop: Bottom Left (Standard) */
          md:flex-row md:gap-3 md:px-3 md:py-2 md:left-4 md:bottom-4 md:top-auto md:translate-y-0 md:rounded-lg md:border-l md:cursor-default md:pointer-events-none md:w-auto md:min-w-0
      `}>
        
        {/* Mobile Toggle Indicator */}
        <div className="flex items-center gap-2 md:hidden">
           <div className="text-gray-500">
              {isStatsExpanded ? <ChevronLeft size={14}/> : <Info size={14}/>}
           </div>
           {!isStatsExpanded && frameIndex !== undefined && (
             <span className="font-mono font-bold">#{frameIndex + 1}</span>
           )}
           {isStatsExpanded && <span className="text-gray-500 font-medium">{labels.frameInfo}</span>}
        </div>

        {/* Stats Content */}
        <div className={`
           flex flex-col gap-2
           ${isStatsExpanded ? 'mt-2' : 'hidden'}
           md:mt-0 md:flex md:flex-row md:gap-3 md:items-center
        `}>
            {frameIndex !== undefined && (
              <>
                <div className="flex gap-1.5 items-center">
                  <span className="text-gray-500 font-medium">#</span>
                  <span className="font-mono">{frameIndex + 1}</span>
                </div>
                <div className="hidden md:block w-px h-3 bg-gray-700 my-auto"></div>
              </>
            )}
            <EditableStat 
              label={labels.time} 
              value={frame.duration} 
              unit="ms" 
              onChange={(val) => onUpdate({ duration: val }, true)} 
            />
            <div className="hidden md:block w-px h-3 bg-gray-700 my-auto"></div>
            <EditableStat 
              label={labels.x} 
              value={Math.round(frame.x)} 
              onChange={(val) => onUpdate({ x: val }, true)} 
            />
            <div className="hidden md:block w-px h-3 bg-gray-700 my-auto"></div>
            <EditableStat 
              label={labels.y} 
              value={Math.round(frame.y)} 
              onChange={(val) => onUpdate({ y: val }, true)} 
            />
            <div className="hidden md:block w-px h-3 bg-gray-700 my-auto"></div>
            <EditableStat 
              label={labels.w} 
              value={Math.round(frame.width)} 
              onChange={(val) => onUpdate({ width: val }, true)} 
            />
            <div className="hidden md:block w-px h-3 bg-gray-700 my-auto"></div>
            <EditableStat 
              label={labels.h} 
              value={Math.round(frame.height)} 
              onChange={(val) => onUpdate({ height: val }, true)} 
            />
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-gray-900/90 p-1.5 rounded-lg backdrop-blur-sm border border-gray-700 shadow-lg z-20">
        <button 
          onClick={() => setKeepAspectRatio(!keepAspectRatio)}
          className={`p-1 rounded transition-colors ${keepAspectRatio ? 'text-blue-400 bg-blue-900/30' : 'text-gray-400 hover:bg-gray-700 hover:text-white'}`}
          title={keepAspectRatio ? "Unlock Aspect Ratio" : "Lock Aspect Ratio"}
        >
          {keepAspectRatio ? <Lock size={14} /> : <Unlock size={14} />}
        </button>

        <button 
          onClick={() => setSnapToGrid(!snapToGrid)}
          className={`p-1 rounded transition-colors ${snapToGrid ? 'text-blue-400 bg-blue-900/30' : 'text-gray-400 hover:bg-gray-700 hover:text-white'}`}
          title="Snap to Borders"
        >
          <Magnet size={14} />
        </button>

        <div className="w-px h-4 bg-gray-700 mx-1"></div>

        <button 
          onClick={handleZoomOut}
          className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-white transition-colors"
          title="Zoom Out"
        >
          <ZoomOut size={14} />
        </button>
        
        <span className="text-xs font-mono text-gray-300 w-12 text-center select-none">
          {Math.round(scale * 100)}%
        </span>

        <button 
          onClick={handleZoomIn}
          className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-white transition-colors"
          title="Zoom In"
        >
          <ZoomIn size={14} />
        </button>

        <div className="w-px h-4 bg-gray-700 mx-1"></div>

        <button 
          onClick={handleResetZoom}
          className={`p-1 rounded transition-colors ${isAutoFit ? 'text-blue-400 bg-blue-900/30' : 'text-gray-400 hover:bg-gray-700 hover:text-white'}`}
          title="Auto Fit"
        >
          <Maximize size={14} />
        </button>
      </div>
    </div>
  );
};
